
gradle build -x test
