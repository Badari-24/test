-Dspring.profiles.active=dev 


http://localhost:8080/v2/api-docs
http://localhost:8080/swagger-resources
http://localhost:8080/swagger-ui.html
