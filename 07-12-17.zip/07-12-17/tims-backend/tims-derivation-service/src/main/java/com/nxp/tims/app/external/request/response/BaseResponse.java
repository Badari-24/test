package com.nxp.tims.app.external.request.response;

import com.nxp.tims.derivation.exception.ErrorInfo;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BaseResponse {

	private ErrorInfo errorInfo;

}
