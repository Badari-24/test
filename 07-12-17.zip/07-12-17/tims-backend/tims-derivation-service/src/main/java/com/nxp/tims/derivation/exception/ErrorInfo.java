/**
 * Error Info Class
 */
package com.nxp.tims.derivation.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 
 * @author Suresh
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ErrorInfo {

 

	/** code */
	private int code;

	/** type */
	private String type;

	/** message */
	private String message;
}