/**
 * Service class for this application.
 * 
 */
package com.nxp.tims.derivation.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;

import org.cloudfoundry.identity.client.token.GrantType;
import org.cloudfoundry.identity.client.token.TokenRequest;
import org.cloudfoundry.identity.uaa.api.UaaConnectionFactory;
import org.cloudfoundry.identity.uaa.api.common.UaaConnection;
import org.cloudfoundry.identity.uaa.api.common.model.UaaTokenGrantType;
import org.cloudfoundry.identity.uaa.api.group.UaaGroupOperations;
import org.cloudfoundry.identity.uaa.api.user.UaaUserOperations;
import org.cloudfoundry.identity.uaa.scim.ScimGroup;
import org.cloudfoundry.identity.uaa.scim.ScimUser;
import org.cloudfoundry.identity.uaa.scim.ScimUser.Email;
import org.exparity.hamcrest.date.DateMatchers;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.common.AuthenticationScheme;
import org.springframework.stereotype.Service;

import com.auth0.jwt.impl.JWTParser;
import com.auth0.jwt.interfaces.Payload;
import com.nxp.tims.app.external.request.response.BaseResponse;
import com.nxp.tims.app.request.response.DerivationServiceRequest;
import com.nxp.tims.app.request.response.DerivationServiceResponse;
import com.nxp.tims.app.request.response.DerivationServiceStatusEnum;
import com.nxp.tims.cloud.foundry.uaa.api.TIMSUaaConnectionFactory;
import com.nxp.tims.cloud.foundry.uaa.api.common.TIMSUaaConnection;
import com.nxp.tims.cloud.foundry.uaa.api.token.management.TIMSUaaTokenManagementOperations;
import com.nxp.tims.derivation.util.AppProperties;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Badari
 *
 */
@Service
@Slf4j
public class DerivationService {

	private static final Logger LOGGER = LoggerFactory.getLogger(DerivationService.class);

	/*
	private static final String UAA_BASE_URL = "http://34.215.20.243:8080/uaa";
	private final String openIDClientID = "tims.backend.openid.client";
	private final String openIDSecretPassword = "K0#726Gh9KKp0h5_01TIMS";
	private final String emailString = "test@nxp.com";
	private final String TIMS_DI_GROUP="tims.di.group";
	*/
	
	private static final String TOKEN_AUTHORIZATION_PATH="/oauth/authorize";
	private static final String TOKEN_PATH="/oauth/token";
	private static final String GROUP_DISPLAY_NAME="";
	private static final String NEWUSER_GIVEN_NAME="DIUser";
	private static final String NEWUSER_FAMILY_NAME="DIFamily";
	
	
	@Autowired
	private AppProperties timsProperties;
	

	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	private UaaUserOperations userOperations;
	private UaaGroupOperations groupOperations;

	// private String
	// cloudFoundery_NewUserID_Password="f18b538d1be903b6a6f056435b171589caf36bf2";

	/**
	 * Create Token.
	 * 
	 * @return
	 */
	public BaseResponse createToken(DerivationServiceRequest diManagementRequest) {

		DerivationServiceResponse diManagementResponse = new DerivationServiceResponse(); //
		String cloudFoundery_NewUserID = diManagementRequest.getIdentityId();
		String cloudFoundery_NewUserID_Password = diManagementRequest.getFingerPrint().replaceAll("\\s+", "");

		try {
			userOperations = getConnection(getDefaultClientCredentials()).userOperations();
			groupOperations = getConnection(getDefaultClientCredentials()).groupOperations();
			
			
			ScimUser newUser = createNewUser(cloudFoundery_NewUserID,cloudFoundery_NewUserID_Password);
			
			ScimUser createdUser = userOperations.createUser(newUser);
			System.out.println("User created..");
			
			/*
			ScimGroup newGroup = createNewGroup(timsProperties.getUsergroup());
			groupOperations.addMember(newGroup.getId(), createdUser.getUserName());
			System.out.println("Group attached..");
			*/
			
			
			TIMSUaaTokenManagementOperations operations = getConnectionForTokenOperations().tokenOperations();
			System.out.println("Calling createToken..");
			String tokenValue = operations.createToken(getTokenRequest(timsProperties.getOpenidclientid(),
					timsProperties.getSecret(),diManagementRequest.getIdentityId(),diManagementRequest.getFingerPrint()),
					timsProperties.getOpenidclientid(),
					timsProperties.getSecret(),diManagementRequest.getIdentityId(),diManagementRequest.getFingerPrint());
			System.out.println("Token Created..");
			
			diManagementResponse.setDerivedIdentity(tokenValue);
			diManagementResponse.setTokenHash(com.nxp.tims.derivation.util.SecurityUtil.encrypt(tokenValue));
			diManagementResponse.setDiServiceResponseStatus(DerivationServiceStatusEnum.CREATED);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(" Found error createToken error -  " + e.getMessage(), e);
		}
		
		return diManagementResponse;
	}
	
	/**
	 * Creates new token for existing user
	 * 
	 * @param diManagementRequest
	 * @return
	 */
	public BaseResponse createNewTokenForExistingUser(DerivationServiceRequest diManagementRequest){
		DerivationServiceResponse diManagementResponse = new DerivationServiceResponse(); //
		
		try {
			groupOperations = getConnection(getDefaultClientCredentials()).groupOperations();
			
			TIMSUaaTokenManagementOperations operations = getConnectionForTokenOperations().tokenOperations();
			LOGGER.info("Calling CF createToken service for existing user");
			String tokenValue = operations.createToken(getTokenRequest(timsProperties.getOpenidclientid(),
					timsProperties.getSecret(),diManagementRequest.getIdentityId(),diManagementRequest.getFingerPrint()),
					timsProperties.getOpenidclientid(),
					timsProperties.getSecret(),diManagementRequest.getIdentityId(),diManagementRequest.getFingerPrint());
			LOGGER.info("Token Created for existing user");
			
			diManagementResponse.setDerivedIdentity(tokenValue);
			diManagementResponse.setTokenHash(com.nxp.tims.derivation.util.SecurityUtil.encrypt(tokenValue));
			diManagementResponse.setDiServiceResponseStatus(DerivationServiceStatusEnum.CREATED);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(" Found error createToken error -  " + e.getMessage(), e);
		}
		return diManagementResponse;
	}
	
	private ScimGroup createNewGroup(String groupName) {
		ScimGroup newGroup = new ScimGroup();
		newGroup.setDisplayName(groupName);
		ScimGroup createdGroup = groupOperations.createGroup(newGroup);
		return createdGroup;
	}
	
	
	private ScimUser createNewUser(String identity,String fingerPrint) {

		ScimUser newUser = new ScimUser();
		newUser.setUserName(identity);
		newUser.setPassword(fingerPrint);
		// newUser.setName(new Name("Test", "User"));
		Email email = new Email();
		email.setValue("enrollmentadministrator@tims.com");
		newUser.setEmails(Collections.singletonList(email));
		// PhoneNumber phone = new PhoneNumber();
		// phone.setValue("303-555-1212");
		// newUser.setPhoneNumbers(Collections.singletonList(phone));
		newUser.setActive(true);
		newUser.setVerified(true);
		newUser.setOrigin("");
		newUser.setGroups(Arrays.asList(new ScimUser.Group(timsProperties.getUsergroup(), GROUP_DISPLAY_NAME)));
		return newUser;
	}

	/**
	 * Revoke Token from TIMS Database.
	 * 
	 */
	public void revokeToken() {
		// TODO : Implementation.
	}

	/**
	 * Revoke List of Tokens.
	 * 
	 */
	public void revokeListOfTokens() {
		// TODO : Implementation.
	}

	/**
	 * Revoke & Create Token.
	 * 
	 */
	public void revokeCreateToken() {
		// TODO : Implementation.
	}

	/**
	 * Validate Token.
	 * 
	 */
	public boolean validateToken(String token) throws Exception{
 
	//	operations = getConnectionWithNoCredentials().tokenOperations();
		TIMSUaaTokenManagementOperations operations = getConnectionForTokenOperations().tokenOperations();
		String json = operations.checkToken(token,timsProperties.getOpenidclientid(),timsProperties.getSecret());
		checkToken(json);
		return true;
	}

	private UaaConnection getConnection(OAuth2ProtectedResourceDetails clientCredentials) throws Exception {
		return UaaConnectionFactory.getConnection(new URL(timsProperties.getCloudfoundryurl()), clientCredentials);
	}
	
	public void checkToken(String tokenAsStr) {

		JWTParser k = new JWTParser();
		Payload jwt = k.parsePayload(tokenAsStr);
		System.out.println("pload  " + jwt.getExpiresAt());

		assertThat(jwt, is(notNullValue()));
		assertThat(jwt.getExpiresAt(), is(instanceOf(Date.class)));
		Date expectedDate = new Date();
		assertThat(jwt.getExpiresAt(), DateMatchers.after(expectedDate));
		/*
		assertThat(jwt.getSubject(), is(notNullValue()));
		assertThat(jwt.getIssuer(), is(notNullValue()));
		assertThat(jwt.getClaims(), is(notNullValue()));
		assertThat(jwt.getClaims(), is(instanceOf(Map.class)));
		assertThat(jwt.getClaims().get("sub"), is(notNullValue()));
		assertThat(jwt.getClaims().get("email").asString(), is("enrollmentadministrator@tims.com"));
		assertThat(jwt.getClaims().get("user_id"), is(notNullValue()));
		assertThat(jwt.getClaims().get("user_name").asString(), is("54b7a427f-2a22-412d-b12e-1abd7cf46532c"));
		assertThat(jwt.getClaims().get("origin").asString(), is("uaa"));
		assertThat(jwt.getClaims().get("client_id").asString(), is("tims.credential.enrollment"));
		assertThat(jwt.getClaims().get("grant_type").asString(), is("password"));
		*/
		System.out.println("validation pass");
	}
	
	 
	
	protected TIMSUaaConnection getConnectionForTokenOperations() throws Exception {
		return TIMSUaaConnectionFactory.getConnection(new URL(timsProperties.getCloudfoundryurl()));
	}


	private TokenRequest getTokenRequest(String clientId,String clientSecret,String userId,String password) throws URISyntaxException {
		TokenRequest tknRequest = new TokenRequest(new URI(TOKEN_PATH), new URI(TOKEN_AUTHORIZATION_PATH));
		tknRequest.setClientId(clientId);
		tknRequest.setClientSecret(clientSecret);
		tknRequest.setGrantType(GrantType.PASSWORD);
		tknRequest.setUsername(userId);
		tknRequest.setPassword(password);
		System.out.println("getTokenRequest is over");
		
		return tknRequest;
	}
	
	protected ClientCredentialsResourceDetails getDefaultClientCredentials() {

		ClientCredentialsResourceDetails clientCredentialsResourceDetails = new ClientCredentialsResourceDetails();
		clientCredentialsResourceDetails.setClientAuthenticationScheme(AuthenticationScheme.header);
		clientCredentialsResourceDetails.setAccessTokenUri(timsProperties.getCloudfoundryurl() + TOKEN_PATH);
		clientCredentialsResourceDetails.setClientId(timsProperties.getOpenidclientid());
		clientCredentialsResourceDetails.setClientSecret(timsProperties.getSecret());
		clientCredentialsResourceDetails.setGrantType(UaaTokenGrantType.client_credentials.toString());

		return clientCredentialsResourceDetails;
	}
	
}
