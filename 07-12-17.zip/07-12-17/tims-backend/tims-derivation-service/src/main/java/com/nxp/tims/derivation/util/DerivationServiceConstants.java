/**
 * Constants class for this application.
 */
package com.nxp.tims.derivation.util;

/**
 * 
 * @author Badari
 *
 */
public final class DerivationServiceConstants {
	/** CREATE_TOKEN_URL */
	public final static String CREATE_TOKEN_URL = "/timsDI/createToken";
	
	/** CREATE_NEW_TOKEN_URL */
	public final static String CREATE_NEW_TOKEN_URL = "/timsDI/createNewToken";
	
	/** REVOKE_TOKEN_URL */
	public final static String REVOKE_TOKEN_URL = "/timsDI/revokeToken";
	
	/** REVOKE_LIST_OF_TOKENS_URL */
	public final static String REVOKE_LIST_OF_TOKENS_URL = "/timsDI/revokeListOfTokens";
	
	/** REVOKE_CREATE_TOKEN_URL */
	public final static String REVOKE_CREATE_TOKEN_URL = "/timsDI/revokeAndCreateToken";
	
	/** VALIDATE_TOKEN_URL */
	public final static String VALIDATE_TOKEN_URL = "/timsDI/validateToken";
	
}
