package com.nxp.tims.derivation.util;

import java.security.MessageDigest;

import com.nxp.tims.app.external.request.response.BaseResponse;
import com.nxp.tims.derivation.exception.ErrorInfo;

public class DerivationUtil {

	 
	public static String digestToken(String plainText){
		//String plainText = "text" + "salt";
		byte[] hash=null;
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
			hash = messageDigest.digest( plainText.getBytes() );	
		}catch(Exception e){
			e.printStackTrace();
		}
		return new String(hash);  
	}
	
	public static BaseResponse returnErrorResponse(int errorCode, String businessMessage, String type) {
		BaseResponse baseResponse = new BaseResponse();
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setCode(errorCode);
		errorInfo.setMessage(businessMessage);
		errorInfo.setType(type);
		baseResponse.setErrorInfo(errorInfo);
		
		return baseResponse;
	}
}
