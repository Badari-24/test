/**
 * This class exposes application services as REST services. 
 */
package com.nxp.tims.derivation.controller;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nxp.tims.app.external.request.response.BaseResponse;
import com.nxp.tims.app.request.response.CheckTokenWithUAARequest;
import com.nxp.tims.app.request.response.CheckTokenWithUAAResponse;
import com.nxp.tims.app.request.response.DerivationServiceRequest;
import com.nxp.tims.derivation.service.DerivationService;
import com.nxp.tims.derivation.util.DerivationServiceConstants;
import com.nxp.tims.derivation.util.DerivationUtil;

import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author Badari
 *
 */
@RestController
public class DerivationController {
	
	

	/** Logger for this class */
	private static final Logger LOGGER = LoggerFactory.getLogger(DerivationController.class);
	
	/** Injecting DIManagementService into this class */
	@Autowired
	private DerivationService identityManagementService;

	/**
	 * Creating Token by calling CF API.
	 * 
	 * @return
	 */
	@ApiOperation(value = "Creates Token", notes = "Creates Token in Clound Foundry", response = String.class)
	@RequestMapping(method = RequestMethod.POST, value = DerivationServiceConstants.CREATE_TOKEN_URL,consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public  BaseResponse createToken(@RequestBody DerivationServiceRequest diManagementRequest) {
		LOGGER.debug("DIController entered into CreateToken() method");
		LOGGER.info("Deriviation service Initiated...");
		String errorMessage = "";
		try {
			return identityManagementService.createToken(diManagementRequest);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			errorMessage = e.getMessage();
		}
		LOGGER.info("Deriviation service completed...");
		LOGGER.debug("Exist from : DIController getDI() method");
		return DerivationUtil.returnErrorResponse(3001, errorMessage, null);
	}
	
	/**
	 * Creating Token by calling CF API.
	 * 
	 * @return
	 */
	@ApiOperation(value = "Creates New Token For Existing User", notes = "Creates Token in Clound Foundry", response = String.class)
	@RequestMapping(method = RequestMethod.POST, value = DerivationServiceConstants.CREATE_NEW_TOKEN_URL,consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public  BaseResponse createNewTokenForExistingUser(@RequestBody DerivationServiceRequest diManagementRequest) {
		LOGGER.debug("DIController entered into createNewTokenForExistingUser() method");
		LOGGER.info("Deriviation service Initiated...");
		String errorMessage = "";
		try {
			return identityManagementService.createNewTokenForExistingUser(diManagementRequest);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			errorMessage = e.getMessage();
		}
		LOGGER.info("Deriviation service completed...");
		LOGGER.debug("Exist from : DIController createNewTokenForExistingUser() method");
		return DerivationUtil.returnErrorResponse(3001, errorMessage, null);
	}
	
	/**
	 * Revoke Token from TIMS Database.
	 * 
	 * @return
	 */
	@ApiOperation(value = "Revokes Token", notes = "Revokes token ", response = String.class)
	@RequestMapping(method = RequestMethod.GET, value = DerivationServiceConstants.REVOKE_TOKEN_URL, produces = MediaType.APPLICATION_JSON_VALUE, headers = "X-API-Version=v1")
	@ResponseBody
	public Response revokeToken() {
		return Response.status(Status.OK).build();
	}
	
	/**
	 *  Revoke List of Tokens.
	 *  
	 * @return
	 */
	@ApiOperation(value = "Revoke List of Tokens", notes = "Revoke list of tokens from TIMS Database.", response = String.class)
	@RequestMapping(method = RequestMethod.GET, value = DerivationServiceConstants.REVOKE_LIST_OF_TOKENS_URL, produces = MediaType.APPLICATION_JSON_VALUE, headers = "X-API-Version=v1")
	@ResponseBody
	public Response revokeListOfTokens() {
		return Response.status(Status.OK).build();
	}
	
	/**
	 * Revoke & Create Token
	 * 
	 * @return
	 */
	@ApiOperation(value = "Revoke and Create Token", notes = "Revoke and create token in TIMS Portal Schema.", response = String.class)
	@RequestMapping(method = RequestMethod.GET, value = DerivationServiceConstants.REVOKE_CREATE_TOKEN_URL, produces = MediaType.APPLICATION_JSON_VALUE, headers = "X-API-Version=v1")
	@ResponseBody
	public Response revokeCreateToken() {
		return Response.status(Status.OK).build();
	}
	
	/**
	 * 
	 * Validate Token in TIMS Database.
	 * 
	 * @return
	 */
	@ApiOperation(value = "Checks Token Validity with UAA", notes = "", response = CheckTokenWithUAAResponse.class)
	@RequestMapping(method = RequestMethod.GET, value = DerivationServiceConstants.VALIDATE_TOKEN_URL, produces = MediaType.APPLICATION_JSON_VALUE, headers = "X-API-Version=v1")
	@ResponseBody
	public BaseResponse validateToken(@RequestBody CheckTokenWithUAARequest checkTokenWithUAARequest) {
		LOGGER.info("ValidateCertController entered into checkTokenWithUAA() method");
		String errorMessage = "";
		try {
			if(checkTokenWithUAARequest!=null && checkTokenWithUAARequest.getToken()!=null && checkTokenWithUAARequest.getToken().length()>0){
				identityManagementService.validateToken(checkTokenWithUAARequest.getToken());
				
			}else{
				return DerivationUtil.returnErrorResponse(3003, errorMessage, null);
			}
			 
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			errorMessage = e.getMessage();

		}

		
		/*
		public void checkToken(String tokenAsStr) {

			JWTParser k = new JWTParser();
			Payload jwt = k.parsePayload(tokenAsStr);
			System.out.println("pload  " + jwt.getExpiresAt());

			assertThat(jwt, is(notNullValue()));
			assertThat(jwt.getExpiresAt(), is(instanceOf(Date.class)));
			Date expectedDate = new Date();
			assertThat(jwt.getExpiresAt(), DateMatchers.after(expectedDate));

			assertThat(jwt.getSubject(), is(notNullValue()));
			assertThat(jwt.getIssuer(), is(notNullValue()));
			assertThat(jwt.getClaims(), is(notNullValue()));
			assertThat(jwt.getClaims(), is(instanceOf(Map.class)));
			assertThat(jwt.getClaims().get("sub"), is(notNullValue()));
			assertThat(jwt.getClaims().get("email").asString(), is("enrollmentadministrator@tims.com"));
			assertThat(jwt.getClaims().get("user_id"), is(notNullValue()));
			assertThat(jwt.getClaims().get("user_name").asString(), is("54b7a427f-2a22-412d-b12e-1abd7cf46532c"));
			assertThat(jwt.getClaims().get("origin").asString(), is("uaa"));
			assertThat(jwt.getClaims().get("client_id").asString(), is("tims.credential.enrollment"));
			assertThat(jwt.getClaims().get("grant_type").asString(), is("password"));
			System.out.println("validation pass");
		}

		@Test
		public void testCheckToken() throws Exception {

			String token = "eyJhbGciOiJIUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiIxYWZhZjlkMWFiY2Y0NGMzODUzMjUwNDJmZjliMzNkMSIsInN1YiI6ImJmN2Q4ODAzLTk5MWUtNDI1ZS1hNGMwLWEzZjcxNDU5NTU4ZSIsInNjb3BlIjpbInVhYS51c2VyIl0sImNsaWVudF9pZCI6InRpbXMuY3JlZGVudGlhbC5lbnJvbGxtZW50IiwiY2lkIjoidGltcy5jcmVkZW50aWFsLmVucm9sbG1lbnQiLCJhenAiOiJ0aW1zLmNyZWRlbnRpYWwuZW5yb2xsbWVudCIsImdyYW50X3R5cGUiOiJwYXNzd29yZCIsInVzZXJfaWQiOiJiZjdkODgwMy05OTFlLTQyNWUtYTRjMC1hM2Y3MTQ1OTU1OGUiLCJvcmlnaW4iOiJ1YWEiLCJ1c2VyX25hbWUiOiI1NGI3YTQyN2YtMmEyMi00MTJkLWIxMmUtMWFiZDdjZjQ2NTMyYyIsImVtYWlsIjoiZW5yb2xsbWVudGFkbWluaXN0cmF0b3JAdGltcy5jb20iLCJhdXRoX3RpbWUiOjE1MTE1MTc4NjgsInJldl9zaWciOiI5ZjhhMzc0ZiIsImlhdCI6MTUxMTUxNzg2OCwiZXhwIjoxNTExNjA0MjY4LCJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjgwODAvdWFhL29hdXRoL3Rva2VuIiwiemlkIjoidWFhIiwiYXVkIjpbInVhYSIsInRpbXMuY3JlZGVudGlhbC5lbnJvbGxtZW50Il19.2FuIuHNJqCQ4T-B6BqLlLvyyOYuUdXr5llQmINT0Qks";
			operations = getConnectionWithNoCredentials().tokenOperations();
			String json = operations.checkToken(token);

			checkToken(json);

		}*/
		
		
		LOGGER.info("Exist from : ValidateCertController checkCertValidation() method");
		return DerivationUtil.returnErrorResponse(3004, errorMessage, null);
	}
	
	 @RequestMapping("/")
	    public String rootindex() {
	        return "Root::Derivation service is Running!!";
	    }
	
	
	 

}