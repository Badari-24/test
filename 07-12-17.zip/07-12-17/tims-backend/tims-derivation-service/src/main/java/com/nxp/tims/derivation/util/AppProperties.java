/**
 * 
 */
package com.nxp.tims.derivation.util;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Badari
 *
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Component
@ConfigurationProperties(prefix = "tims") // prefix app, find user.* values
public class AppProperties {

	/** Cloud Foundry URL */
	private String cloudfoundryurl;
	
	/** openidclientid */
	private String openidclientid;
	
	/** secret */
	private String secret;
	
	/** User Email */
	private String useremail;
	
	
	/** User Group */
	private String usergroup;
	 
	
	
}