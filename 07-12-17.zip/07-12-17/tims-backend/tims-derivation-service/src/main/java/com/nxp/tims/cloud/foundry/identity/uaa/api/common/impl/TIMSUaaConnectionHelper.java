package com.nxp.tims.cloud.foundry.identity.uaa.api.common.impl;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.cloudfoundry.identity.uaa.api.common.impl.UaaConnectionHelper;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.web.client.RestTemplate;

public class TIMSUaaConnectionHelper extends UaaConnectionHelper {

	private URL url;

	private static final Log log = LogFactory.getLog(TIMSUaaConnectionHelper.class);

	/**
	 * Establish connectivity information for this session.
	 * 
	 * @param url
	 * @param creds
	 * @see org.cloudfoundry.identity.uaa.api.UaaConnectionFactory#getConnection(URL,
	 *      OAuth2ProtectedResourceDetails)
	 */
	public TIMSUaaConnectionHelper(URL url) {
		super(url, null);
		this.url = url;
	}

	public <RequestType, ResponseType> ResponseType post(String uri, HttpHeaders headers, RequestType body,
			ParameterizedTypeReference<ResponseType> responseType, Object... uriVariables) {
		return exchange(HttpMethod.POST, headers, body, uri, responseType, uriVariables);
	}

	/**
	 * Make a REST call with custom headers
	 * 
	 * @param method
	 *            the Http Method (GET, POST, etc)
	 * @param uri
	 *            the URI of the endpoint (relative to the base URL set in the
	 *            constructor)
	 * @param body
	 *            the request body
	 * @param responseType
	 *            the object type to be returned
	 * @param uriVariables
	 *            any uri variables
	 * @return the response body
	 * @see org.springframework.web.client.RestTemplate#exchange(String, HttpMethod,
	 *      HttpEntity, ParameterizedTypeReference, Object...)
	 */
	private <RequestType, ResponseType> ResponseType exchange(HttpMethod method, HttpHeaders headers, RequestType body,
			String uri, ParameterizedTypeReference<ResponseType> responseType, Object... uriVariables) {

		RestTemplate template = new RestTemplate();
		template.setInterceptors(LoggerInterceptor.INTERCEPTOR);

		HttpEntity<RequestType> requestEntity = null;
		if (body == null) {
			requestEntity = new HttpEntity<RequestType>(headers);
		} else {
			requestEntity = new HttpEntity<RequestType>(body, headers);
		}

		// combine url into the varargs
		List<Object> varList = new ArrayList<Object>();
		varList.add(url);
		if (uriVariables != null && uriVariables.length > 0) {
			varList.addAll(Arrays.asList(uriVariables));
		}

		ResponseEntity<ResponseType> responseEntity = template.exchange("{base}" + uri, method, requestEntity,
				responseType, varList.toArray());

		if (HttpStatus.Series.SUCCESSFUL.equals(responseEntity.getStatusCode().series())) {
			return responseEntity.getBody();
		} else {
			return null;
		}
	}

	/**
	 * An interceptor used to log information about HTTP calls
	 * 
	 * @author Josh Ghiloni
	 *
	 */
	private static class LoggerInterceptor implements ClientHttpRequestInterceptor {
		public static final List<ClientHttpRequestInterceptor> INTERCEPTOR = Arrays
				.<ClientHttpRequestInterceptor>asList(new LoggerInterceptor());

		public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
				throws IOException {
			if (log.isDebugEnabled()) {
				log.debug(new String(body, "UTF-8"));
			}

			return execution.execute(request, body);
		}
	}

}
