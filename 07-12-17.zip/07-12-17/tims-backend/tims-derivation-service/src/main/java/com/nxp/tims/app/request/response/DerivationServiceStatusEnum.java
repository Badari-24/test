package com.nxp.tims.app.request.response;

public enum DerivationServiceStatusEnum {

	CREATED(1),FAILED(-1);
	
	private int id;
	
	DerivationServiceStatusEnum(int id){
		this.id = id; 
	}
	
	public int id(){
		return id; 
	}
}
