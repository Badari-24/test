package com.nxp.tims.cloud.foundry.uaa.api.common;

import org.cloudfoundry.identity.uaa.api.common.UaaConnection;

import com.nxp.tims.cloud.foundry.uaa.api.token.management.TIMSUaaTokenManagementOperations;

public interface TIMSUaaConnection extends UaaConnection {

	public TIMSUaaTokenManagementOperations tokenOperations();
}
