/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.nxp.tims.cloud.foundry.uaa.api.token.management;

import org.cloudfoundry.identity.client.token.TokenRequest;

public interface TIMSUaaTokenManagementOperations {
		
	public String createToken(TokenRequest tknRequest,String clientId,String secret,String userId,String password);

	public String checkToken(String token,String clientId,String secret);

	public boolean revokeToken(String token);

	public boolean revokeTokensForUser(String userID);

	public boolean revokeTokensForClient(String clientID);

}