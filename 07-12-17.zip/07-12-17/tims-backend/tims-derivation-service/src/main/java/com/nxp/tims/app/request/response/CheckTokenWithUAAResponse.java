package com.nxp.tims.app.request.response;

public class CheckTokenWithUAAResponse {
	CheckTokenWithUAAResponseEnum status;
}
