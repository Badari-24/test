package com.nxp.tims.cloud.foundry.uaa.api;

import java.net.URL;

import org.cloudfoundry.identity.uaa.api.common.UaaConnection;
import org.cloudfoundry.identity.uaa.api.common.impl.UaaConnectionHelper;
import org.cloudfoundry.identity.uaa.api.common.impl.UaaConnectionImpl;

import com.nxp.tims.cloud.foundry.identity.uaa.api.common.impl.TIMSUaaConnectionHelper;
import com.nxp.tims.cloud.foundry.identity.uaa.api.common.impl.TIMSUaaConnectionImpl;
import com.nxp.tims.cloud.foundry.uaa.api.common.TIMSUaaConnection;

public class TIMSUaaConnectionFactory {

	private TIMSUaaConnectionFactory() {

	}

	public static TIMSUaaConnection getConnection(URL uaaUrl) {
		TIMSUaaConnectionHelper helper = new TIMSUaaConnectionHelper(uaaUrl);
		return new TIMSUaaConnectionImpl(helper);
	}
}
