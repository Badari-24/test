package com.nxp.tims.app.request.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DerivationServiceRequest {

	  private String deviceId;
	  private String identityId;
	  private String fingerPrint; 
}
