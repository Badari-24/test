package com.nxp.tims.app.request.response;

import com.nxp.tims.app.external.request.response.BaseRequest;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CheckTokenWithUAARequest extends BaseRequest{
  private String token;
}
