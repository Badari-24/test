package com.nxp.tims.cloud.foundry.uaa.api.token.management.impl;

import static java.lang.String.format;

import java.io.UnsupportedEncodingException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.cloudfoundry.identity.client.token.TokenRequest;
import org.cloudfoundry.identity.uaa.oauth.token.CompositeAccessToken;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.codec.Base64;
import org.springframework.security.oauth2.common.util.OAuth2Utils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.nxp.tims.cloud.foundry.identity.uaa.api.common.impl.TIMSUaaConnectionHelper;
import com.nxp.tims.cloud.foundry.uaa.api.token.management.TIMSUaaTokenManagementOperations;

public class TIMSUaaTokenManagementOperationsImpl implements TIMSUaaTokenManagementOperations {

	private static final Log log = LogFactory.getLog(TIMSUaaTokenManagementOperationsImpl.class);

	private static final ParameterizedTypeReference<String> STRING_REF = new ParameterizedTypeReference<String>() {
	};

	private static final ParameterizedTypeReference<CompositeAccessToken> TOKEN_REF = new ParameterizedTypeReference<CompositeAccessToken>() {
	};

	private TIMSUaaConnectionHelper helper;

	protected String getClientBasicAuthHeader() {
		try {
			byte[] autbytes = Base64
					.encode(format("%s:%s", "tims.credential.enrollment", "K0#726Gh9KKp0h5").getBytes("UTF-8"));
			String base64 = new String(autbytes);
			return format("Basic %s", base64);
		} catch (UnsupportedEncodingException e) {
			throw new IllegalArgumentException(e);
		}
	}

	public TIMSUaaTokenManagementOperationsImpl(TIMSUaaConnectionHelper helper) {
		this.helper = helper;
	}

	@Override
	public String checkToken(String token,String clientId,String secret){

		Map<String, Object> request = new HashMap<String, Object>(1);
		request.put("token", token);

		String clientBasicAuth = getClientBasicAuthHeader();

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.add(HttpHeaders.AUTHORIZATION, clientBasicAuth);

		String data = "token=" + token;
		String json = helper.post("/check_token", headers, data, STRING_REF, (Object[]) null);
		return json;

	}

	public String createToken(TokenRequest tknRequest,String clientId,String secret,String userId,String password) {

		if (!tknRequest.isValid()) {
			throw new RuntimeException(
					"Invalid request, at least one token request parameter missing. Please refer to specs.");
		}

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

		MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
		form.add(OAuth2Utils.GRANT_TYPE, "password");
		form.add(OAuth2Utils.RESPONSE_TYPE, "token");
		
	//	form.add(OAuth2Utils.CLIENT_ID, "tims.credential.enrollment");
//		form.add("client_secret", "K0#726Gh9KKp0h5");
//		form.add("username", "54b7a427f-2a22-412d-b12e-1abd7cf46532c");
//		form.add("password", "f18b538d1be903b6a6f056435b171589caf36bf2");

		form.add(OAuth2Utils.CLIENT_ID, clientId);
		form.add("client_secret", secret);
		form.add("username", userId);
		form.add("password", password);
		
		
		CompositeAccessToken token = helper.post("/oauth/token", headers, form, TOKEN_REF, (Object[]) null);
		return token.getValue();
	}

	@Override
	public boolean revokeToken(String token) {

		helper.delete("/oauth/token/revoke/{token}", STRING_REF, token);
		return true;
	}

	@Override
	public boolean revokeTokensForUser(String userID) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean revokeTokensForClient(String clientID) {
		// TODO Auto-generated method stub
		return false;
	}

}
