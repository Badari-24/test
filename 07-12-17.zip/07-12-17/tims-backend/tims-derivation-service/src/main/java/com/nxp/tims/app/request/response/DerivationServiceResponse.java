package com.nxp.tims.app.request.response;

import com.nxp.tims.app.external.request.response.BaseResponse;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class DerivationServiceResponse extends BaseResponse {

	private String derivedIdentity;
	private String originHash;
	private String tokenHash; 
	private DerivationServiceStatusEnum diServiceResponseStatus;
	
}
