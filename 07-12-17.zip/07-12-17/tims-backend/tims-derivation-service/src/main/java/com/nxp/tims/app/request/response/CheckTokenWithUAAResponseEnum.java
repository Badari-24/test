package com.nxp.tims.app.request.response;

public enum CheckTokenWithUAAResponseEnum {
   GOOD,BAD,UNKNOWN
}
