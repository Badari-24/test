/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.nxp.tims.cloud.foundry.token.operation.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Collections;

import org.cloudfoundry.identity.uaa.api.common.model.UaaTokenGrantType;
import org.cloudfoundry.identity.uaa.api.common.model.expr.FilterRequestBuilder;
import org.cloudfoundry.identity.uaa.api.group.UaaGroupOperations;
import org.cloudfoundry.identity.uaa.api.user.UaaUserOperations;
import org.cloudfoundry.identity.uaa.rest.SearchResults;
import org.cloudfoundry.identity.uaa.scim.ScimGroup;
import org.cloudfoundry.identity.uaa.scim.ScimUser;
import org.cloudfoundry.identity.uaa.scim.ScimUser.Email;
import org.cloudfoundry.identity.uaa.scim.ScimUser.PhoneNumber;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.common.AuthenticationScheme;

/**
 * @author Josh Ghiloni
 */
public class TIMSUaaUserOperationTest extends TIMSAbstractOperationTest {

	@ClassRule
	public static TIMSUaaServerAvailable uaaServerAvailable = new TIMSUaaServerAvailable();
	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	private UaaUserOperations userOperations;

	private UaaGroupOperations groupOperations;

	private static final String UAA_BASE_URL = "http://34.215.20.243:8080/uaa";

	@Before
	public void setUp() throws Exception {

		ClientCredentialsResourceDetails credentialType = new ClientCredentialsResourceDetails();

		credentialType.setClientAuthenticationScheme(AuthenticationScheme.header);
		credentialType.setAccessTokenUri(UAA_BASE_URL + "/oauth/token");
		credentialType.setClientId("tims.credential.enrollment");
		credentialType.setClientSecret("K0#726Gh9KKp0h5");
		credentialType.setGrantType(UaaTokenGrantType.client_credentials.toString());
		userOperations = getConnection(credentialType).userOperations();
		groupOperations = getConnection(credentialType).groupOperations();
	}

	@Test
	public void testCreateDeleteUser() {

		ScimUser newUser = createNewTestUser();

		ScimUser createdUser = userOperations.createUser(newUser);
		System.out.println("user created with ID " + createdUser.getId());
		assertNotNull(createdUser.getId());

		ScimGroup newGroup = createNewGroup();
		System.out.println("grp created with ID " + newGroup.getId());
		groupOperations.addMember(newGroup.getId(), createdUser.getUserName());

		System.out.println("member added to the group");
//		userOperations.deleteUser(createdUser.getId());
//		groupOperations.deleteGroup(newGroup.getId());
//		System.out.println("user and group deleted");
	}

	public void testUserRetrieval() {

		SearchResults<ScimUser> users = userOperations.getUsers(FilterRequestBuilder.showAll());

		assertNotNull(users);

		assertEquals(1, users.getTotalResults());
		assertEquals(1, users.getResources().size());
		assertEquals(1, users.getStartIndex());
		assertEquals(100, users.getItemsPerPage());
	}

	public void testUserCreateUpdateDelete() {

		ScimUser newUser = createNewTestUser();

		ScimUser createdUser = userOperations.createUser(newUser);
		assertNotNull(createdUser.getId());

		PhoneNumber updatedPhone = new PhoneNumber();
		updatedPhone.setValue("212-867-5309");
		createdUser.setPhoneNumbers(Collections.singletonList(updatedPhone));
		ScimUser updatedUser = userOperations.updateUser(createdUser);

		assertEquals(createdUser.getId(), updatedUser.getId());
	}

	public void testUserPasswordChange() {

		ScimUser newUser = createNewTestUser();
		ScimUser createdUser = userOperations.createUser(newUser);

		userOperations.changeUserPassword(createdUser.getId(), newUser.getPassword(), "newk0ala");
	}

	private ScimGroup createNewGroup() {
		ScimGroup newGroup = new ScimGroup();
		newGroup.setDisplayName("tims.identity.group");
		ScimGroup createdGroup = groupOperations.createGroup(newGroup);
		return createdGroup;
	}

	private ScimUser createNewTestUser() {

		ScimUser newUser = new ScimUser();

		newUser.setUserName("54b7a427f-2a22-412d-b12e-1abd7cf46532c");
		newUser.setPassword("f18b538d1be903b6a6f056435b171589caf36bf2");

		// newUser.setName(new Name("Test", "User"));

		Email email = new Email();
		email.setValue("enrollmentadministrator@tims.com");

		newUser.setEmails(Collections.singletonList(email));

		// PhoneNumber phone = new PhoneNumber();
		// phone.setValue("303-555-1212");
		// newUser.setPhoneNumbers(Collections.singletonList(phone));

		newUser.setActive(true);
		newUser.setVerified(true);
		newUser.setOrigin("");

		return newUser;
	}

}
