/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.nxp.tims.cloud.foundry.token.operation.test;

import java.net.URL;

import org.cloudfoundry.identity.uaa.api.UaaConnectionFactory;
import org.cloudfoundry.identity.uaa.api.common.UaaConnection;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.common.AuthenticationScheme;

import com.nxp.tims.cloud.foundry.uaa.api.TIMSUaaConnectionFactory;
import com.nxp.tims.cloud.foundry.uaa.api.common.TIMSUaaConnection;


public abstract class TIMSAbstractOperationTest {

	private static final String UAA_BASE_URL = "http://34.215.20.243:8080/uaa";

	protected ClientCredentialsResourceDetails getDefaultClientCredentials() {

		ClientCredentialsResourceDetails credentials = new ClientCredentialsResourceDetails();
		credentials.setAccessTokenUri(UAA_BASE_URL + "/oauth/token");
		credentials.setClientAuthenticationScheme(AuthenticationScheme.header);
		credentials.setClientId("admin");
		credentials.setClientSecret("adminsecret");

		return credentials;
	}

	protected UaaConnection getConnection() throws Exception {
		return getConnection(getDefaultClientCredentials());
	}

	protected TIMSUaaConnection getConnectionForTokenOperations() throws Exception {
		return TIMSUaaConnectionFactory.getConnection(new URL(UAA_BASE_URL));
	}

	protected UaaConnection getConnection(OAuth2ProtectedResourceDetails clientCredentials) throws Exception {
		return UaaConnectionFactory.getConnection(new URL(UAA_BASE_URL), clientCredentials);
	}

}
