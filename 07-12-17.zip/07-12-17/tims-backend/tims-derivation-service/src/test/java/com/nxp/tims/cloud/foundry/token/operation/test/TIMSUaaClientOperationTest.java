/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.nxp.tims.cloud.foundry.token.operation.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.cloudfoundry.identity.uaa.api.client.UaaClientOperations;
import org.cloudfoundry.identity.uaa.api.common.model.UaaTokenGrantType;
import org.cloudfoundry.identity.uaa.api.common.model.expr.FilterRequestBuilder;
import org.cloudfoundry.identity.uaa.rest.SearchResults;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.provider.client.BaseClientDetails;
import org.springframework.web.client.HttpStatusCodeException;


public class TIMSUaaClientOperationTest extends TIMSAbstractOperationTest {

	@ClassRule
	public static TIMSUaaServerAvailable uaaServerAvailable = new TIMSUaaServerAvailable();

	private UaaClientOperations operations;
	private BaseClientDetails testClient;
	private BaseClientDetails testClientDetails;

	@Before
	public void setup() throws Exception {
	
		operations = getConnection().clientOperations();
		
		try {
			operations.delete("tims.credential.enrollment");
		} catch (Exception ignore) {}

		testClientDetails = new BaseClientDetails();
		testClientDetails.setClientId("tims.credential.enrollment");
		testClientDetails.setClientSecret("K0#726Gh9KKp0h5");
		Map<String, Object> addnalInfo = new LinkedHashMap<String, Object>();
		addnalInfo.put("allowedproviders", Arrays.asList("uaa"));
		addnalInfo.put("token_salt", "1a2tNG");
		addnalInfo.put("name", "TIMS Enrollment Admin");
		testClientDetails.setAdditionalInformation(addnalInfo);
		testClientDetails.setAccessTokenValiditySeconds(24*60*60);
		testClientDetails.setAutoApproveScopes(Arrays.asList("true"));
		testClientDetails.setAuthorizedGrantTypes(Arrays.asList(UaaTokenGrantType.password.toString(),
				UaaTokenGrantType.client_credentials.toString(), UaaTokenGrantType.refresh_token.toString()));
		testClientDetails.setRefreshTokenValiditySeconds(24*60*60);
		testClientDetails.setAuthorities(AuthorityUtils.createAuthorityList("uaa.resource", "uaa.admin"));
		testClientDetails.setScope(Arrays.asList("uaa.user"));
		try {
			testClient = operations.create(testClientDetails);
		}catch(HttpStatusCodeException httpEx) {
			System.out.println("Failure status code "+httpEx.getResponseBodyAsString());
		}
	}

	public void testGetClients() throws Exception {

		SearchResults<BaseClientDetails> clients = operations.getClients(FilterRequestBuilder.showAll());

		assertEquals("Total Results wrong", 12, clients.getTotalResults()); // default 11 + test client 1 = 12 clients
		assertEquals("Items Per Page wrong", 12, clients.getItemsPerPage());
		assertEquals("Actual result count wrong", 12, clients.getResources().size());
	}

	@Test
	public void testGetClient() throws Exception {

		BaseClientDetails client = operations.findById("tims.credential.enrollment");

		assertEquals("ID wrong", "tims.credential.enrollment", client.getClientId());
		assertNull("Secret should not be returned", client.getClientSecret());
	}

	public void testCreateDelete() throws Exception {

		BaseClientDetails checkClient = operations.findById(testClient.getClientId());
		assertEquals(testClient.getClientId(), checkClient.getClientId());

		operations.delete(checkClient.getClientId());
	}

	public void testUpdate() throws Exception {

		BaseClientDetails client = operations.findById(testClient.getClientId());

		client.setScope(Arrays.asList("foo"));
		BaseClientDetails updated = operations.update(client);

		assertNotEquals(testClient.getScope(), updated.getScope());
		assertEquals(client.getScope().iterator().next(), updated.getScope().iterator().next());
	}

	public void testChangeClientSecretForTestUser() throws Exception {

		ClientCredentialsResourceDetails testUserCredentials = getDefaultClientCredentials();
		testUserCredentials.setClientId(testClientDetails.getClientId());
		testUserCredentials.setClientSecret(testClientDetails.getClientSecret());
		testUserCredentials.setScope(new ArrayList<String>(testClientDetails.getScope()));

		UaaClientOperations clientOperations = getConnection(testUserCredentials).clientOperations();

		String clientSecret = testClientDetails.getClientSecret();

		assertTrue("Could not change password",
				clientOperations.changeClientSecret(testClientDetails.getClientId(), clientSecret, "newSecret"));

		try {
			clientOperations.changeClientSecret(testClientDetails.getClientId(), clientSecret, "shouldfail");
			fail("First password change failed");
		} catch (Exception expected) {
			expected.toString(); // to avoid empty catch-block.
		}
	}
}
