package com.nxp.tims.derivation.junit;

import java.net.URL;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

import org.cloudfoundry.identity.uaa.api.UaaConnectionFactory;
import org.cloudfoundry.identity.uaa.api.client.UaaClientOperations;

import org.cloudfoundry.identity.uaa.api.common.UaaConnection;
import org.cloudfoundry.identity.uaa.api.common.model.UaaTokenGrantType;
import org.junit.ClassRule;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.common.AuthenticationScheme;
import org.springframework.security.oauth2.provider.client.BaseClientDetails;
import org.springframework.web.client.HttpStatusCodeException;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CreateClientTestCase {
	
	
	private UaaClientOperations uaaClientOperations;
	private BaseClientDetails baseClient;
	private BaseClientDetails baseClientDetails;
	
	
	//private static final String UAA_BASE_URL = "http://34.215.20.243:8080/uaa";
	
	private static final String UAA_BASE_URL = "http://18.216.162.81:8080/uaa";
	
	
		

	protected ClientCredentialsResourceDetails getDefaultClientCredentials() {

		ClientCredentialsResourceDetails credentials = new ClientCredentialsResourceDetails();
		credentials.setAccessTokenUri(UAA_BASE_URL + "/oauth/token");
		credentials.setClientAuthenticationScheme(AuthenticationScheme.header);
		credentials.setClientId("admin");
		credentials.setClientSecret("adminsecret");

		return credentials;
	}

	protected UaaConnection getConnection() throws Exception {
		return getConnection(getDefaultClientCredentials());
	}

	protected UaaConnection getConnection(OAuth2ProtectedResourceDetails clientCredentials) throws Exception {
		return UaaConnectionFactory.getConnection(new URL(UAA_BASE_URL), clientCredentials);
	}
	
	
	
	@Test
	public void createClient_Test_01() throws Exception {
		
		uaaClientOperations = getConnection().clientOperations();
		String openIDClientID="tims.backend.openid.client";
		String openIDSecretPassword="K0#726Gh9KKp0h5_01TIMS";
		String openIDClientName="TIMS Enrollment Admin";
		
		
		String openIDClient_TokeSalt="1a2tNG"; 
		try {
			uaaClientOperations.delete(openIDClientID);
		} catch (Exception ignore) {}

		baseClientDetails = new BaseClientDetails();
		baseClientDetails.setClientId(openIDClientID);
		baseClientDetails.setClientSecret(openIDSecretPassword);
		
		Map<String, Object> addnalInfo = new LinkedHashMap<String, Object>();
		addnalInfo.put("allowedproviders", Arrays.asList("uaa"));
		addnalInfo.put("token_salt", openIDClient_TokeSalt);
		addnalInfo.put("name", openIDClientName);
		
		baseClientDetails.setAdditionalInformation(addnalInfo);
		baseClientDetails.setAccessTokenValiditySeconds(24*60*60);
		baseClientDetails.setAutoApproveScopes(Arrays.asList("true"));
		baseClientDetails.setAuthorizedGrantTypes(Arrays.asList(UaaTokenGrantType.password.toString(),
				UaaTokenGrantType.client_credentials.toString(), UaaTokenGrantType.refresh_token.toString()));
		baseClientDetails.setRefreshTokenValiditySeconds(24*60*60);
		baseClientDetails.setAuthorities(AuthorityUtils.createAuthorityList("uaa.resource", "uaa.admin"));
		baseClientDetails.setScope(Arrays.asList("uaa.user"));
		
		try {
			baseClient = uaaClientOperations.create(baseClientDetails);
			System.out.println("CreateClientTestCase -  Response "+ baseClient.toString());
		}catch(HttpStatusCodeException httpEx) {
			System.out.println("Failure status code "+httpEx.getResponseBodyAsString());
		}
		
		//BaseClientDetails [clientId=tims.backend.openid.client, clientSecret=null, scope=[uaa.user], resourceIds=[none], authorizedGrantTypes=[refresh_token, 
		//password, client_credentials], registeredRedirectUris=null, authorities=[uaa.resource, uaa.admin], accessTokenValiditySeconds=86400, 
		//refreshTokenValiditySeconds=86400, additionalInformation={allowedproviders=[uaa], token_salt=1a2tNG, name=TIMS Enrollment Admin, lastModified=1511347699278, 
		//required_user_groups=[]}]
				
	}
	
	
	
	
}
