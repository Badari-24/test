package com.nxp.tims.derivation.junit;

import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;

import org.cloudfoundry.identity.client.UaaContext;
import org.cloudfoundry.identity.client.UaaContextFactory;
import org.cloudfoundry.identity.client.token.GrantType;
import org.cloudfoundry.identity.client.token.TokenRequest;
import org.cloudfoundry.identity.uaa.api.client.UaaClientOperations;
import org.cloudfoundry.identity.uaa.api.common.model.UaaTokenGrantType;
import org.cloudfoundry.identity.uaa.api.group.UaaGroupOperations;
import org.cloudfoundry.identity.uaa.api.user.UaaUserOperations;
import org.cloudfoundry.identity.uaa.scim.ScimGroup;
import org.cloudfoundry.identity.uaa.scim.ScimUser;
import org.cloudfoundry.identity.uaa.scim.ScimUser.Email;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runners.MethodSorters;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.common.AuthenticationScheme;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.nxp.tims.cloud.foundry.token.operation.test.TIMSAbstractOperationTest;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CreateUserAndGenerateTokenTestCase extends TIMSAbstractOperationTest{
	
	private static final String UAA_BASE_URL = "http://34.215.20.243:8080/uaa";
	//http://18.216.162.81:8080/uaa
	private final String openIDClientID="tims.backend.openid.client";
	private final  String openIDSecretPassword="K0#726Gh9KKp0h5_01TIMS";
	
	
	
	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	private UaaUserOperations userOperations;

	private UaaGroupOperations groupOperations;
	
	
	private UaaClientOperations userClientOperations;

	
	@Before
	public void setUp() throws Exception {
		ClientCredentialsResourceDetails credentialType = new ClientCredentialsResourceDetails();
		credentialType.setClientAuthenticationScheme(AuthenticationScheme.header);
		credentialType.setAccessTokenUri(UAA_BASE_URL + "/oauth/token");
		credentialType.setClientId(openIDClientID);
		credentialType.setClientSecret(openIDSecretPassword);
		credentialType.setGrantType(UaaTokenGrantType.client_credentials.toString());
		userOperations = getConnection(credentialType).userOperations();
		groupOperations = getConnection(credentialType).groupOperations();
		
		//userClientOperations = getConnection(credentialType).clientOperations();
		
		
	}
	
	
	 
	
	@Test
	public void test_method_1() throws Exception 
	{
		String cloudFoundery_NewUserID = java.util.UUID.randomUUID().toString();
		String cloudFoundery_NewUserID_Password="f18b538d1be903b6a6f056435b171589caf36bf2";
		ScimUser createdUser=null; 
		ScimGroup createdGroup=null; 
		ScimGroup newGroup=null;
		
		
		//Creating Group  
		try {
			//Creating group
			newGroup = new ScimGroup();
			newGroup.setDisplayName("tims.di.group");
			createdGroup = groupOperations.createGroup(newGroup);
			System.out.println("createdGroup - "+ createdGroup);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		//Creating User
		try {
	
			ScimUser newUser = new ScimUser();
			newUser.setUserName(cloudFoundery_NewUserID);
			newUser.setPassword(cloudFoundery_NewUserID_Password);
			// newUser.setName(new Name("Test", "User"));
			Email email = new Email();
			email.setValue("test@nxp.com");
			newUser.setEmails(Collections.singletonList(email));
			newUser.setGroups(Arrays.asList(new ScimUser.Group("tims.di.group", "test1")));
			
			// PhoneNumber phone = new PhoneNumber();
			// phone.setValue("303-555-1212");
			// newUser.setPhoneNumbers(Collections.singletonList(phone));
			newUser.setActive(true);
			newUser.setVerified(true);
			newUser.setOrigin("");

			createdUser = userOperations.createUser(newUser);
			System.out.println("user created with ID " + createdUser.getId());
			
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
	
		

		//Creating Group  
		try {
			//Creating group
			//System.out.println("suresh - "+newGroup.getId());
			groupOperations.addMember(newGroup.getId(), createdUser.getUserName());
			System.out.println("member added to the group");
		}catch(Exception e){
		}
		

		
		UaaContextFactory factory = UaaContextFactory.factory(new URI(UAA_BASE_URL))
				.authorizePath("/oauth/authorize").tokenPath("/oauth/token");

		TokenRequest tokenRequest = factory.tokenRequest().setClientId(openIDClientID)
				.setClientSecret(openIDSecretPassword).setPassword(cloudFoundery_NewUserID_Password)
				.setUsername(cloudFoundery_NewUserID).setGrantType(GrantType.PASSWORD);
		
		 
		
		// bearer access token returned here
		UaaContext context = factory.authenticate(tokenRequest);
		System.out.println("Received Token value 1  "+ context.getToken().getValue());

		
		
		
		tokenRequest = factory.tokenRequest().setClientId(openIDClientID)
				.setClientSecret(openIDSecretPassword).setPassword(cloudFoundery_NewUserID_Password)
				.setUsername(cloudFoundery_NewUserID).setGrantType(GrantType.PASSWORD);
		System.out.println("Received Token value 2  "+ context.getToken().getValue());
		
		DecodedJWT jwt = JWT.decode(context.getToken().getValue());
		System.out.println(jwt);
		System.out.println(jwt.getExpiresAt());
		System.out.println(jwt.getType());

		Map<String, Claim> clms = jwt.getClaims();

		for (String k : clms.keySet()) {
			System.out.println("Found key [" + k + "], value : [" + ((Claim) clms.get(k)).asString() + "]");
		}
		
		
		
		
		/*
		assertThat(jwt, is(notNullValue()));
		assertThat(jwt.getExpiresAt(), is(instanceOf(Date.class)));
		Date expectedDate = new Date();
		assertThat(jwt.getExpiresAt(), DateMatchers.after(expectedDate));

		assertThat(jwt.getSubject(), is(notNullValue()));
		assertThat(jwt.getIssuer(), is(notNullValue()));
		assertThat(jwt.getClaims(), is(notNullValue()));
		assertThat(jwt.getClaims(), is(instanceOf(Map.class)));
		assertThat(jwt.getClaims().get("sub"), is(notNullValue()));
		assertThat(jwt.getClaims().get("email").asString(), is("enrollmentadministrator@tims.com"));
		assertThat(jwt.getClaims().get("user_id"), is(notNullValue()));
		assertThat(jwt.getClaims().get("user_name").asString(), is("54b7a427f-2a22-412d-b12e-1abd7cf46532c"));
		assertThat(jwt.getClaims().get("origin").asString(), is("uaa"));
		assertThat(jwt.getClaims().get("client_id").asString(), is("tims.credential.enrollment"));
		assertThat(jwt.getClaims().get("grant_type").asString(), is("password"));
	   */
	
		// https://github.com/auth0
	}
}
