/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.nxp.tims.cloud.foundry.token.operation.test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Date;
import java.util.Map;

import org.cloudfoundry.identity.client.token.GrantType;
import org.cloudfoundry.identity.client.token.TokenRequest;
import org.cloudfoundry.identity.uaa.api.common.model.UaaTokenGrantType;
import org.exparity.hamcrest.date.DateMatchers;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.common.AuthenticationScheme;

import com.auth0.jwt.impl.JWTParser;
import com.auth0.jwt.interfaces.Payload;
import com.nxp.tims.cloud.foundry.uaa.api.token.management.TIMSUaaTokenManagementOperations;

public class TIMSUaaTokenManagementOperationTest extends TIMSAbstractOperationTest {

	@ClassRule
	public static TIMSUaaServerAvailable uaaServerAvailable = new TIMSUaaServerAvailable();

	private TIMSUaaTokenManagementOperations operations;

	private static final String UAA_BASE_URL = "http://34.215.20.243:8080/uaa";
	ClientCredentialsResourceDetails credentialType = new ClientCredentialsResourceDetails();

	@Before
	public void setup() throws Exception {

		credentialType.setClientAuthenticationScheme(AuthenticationScheme.header);
		credentialType.setAccessTokenUri(UAA_BASE_URL + "/oauth/token");
		credentialType.setClientId("tims.credential.enrollment");
		credentialType.setClientSecret("K0#726Gh9KKp0h5");
		credentialType.setGrantType(UaaTokenGrantType.client_credentials.toString());

	}

	@Test
	public void testCreateAndValidateToken() throws Exception {

		operations = getConnectionForTokenOperations().tokenOperations();
		String token = operations.createToken(getTokenRequest(),
				"tims.credential.enrollment",
				"K0#726Gh9KKp0h5",
				"54b7a427f-2a22-412d-b12e-1abd7cf46532c",
				"f18b538d1be903b6a6f056435b171589caf36bf2"
				);
		System.out.println("token ceated " + token);
		String json = operations.checkToken(token,"tims.credential.enrollment","K0#726Gh9KKp0h5");
		checkToken(json);

	}

	@Test
	public void testCreateToken() throws Exception {
		operations = getConnectionForTokenOperations().tokenOperations();
		String token = operations.createToken(getTokenRequest(),
				"tims.credential.enrollment",
				"K0#726Gh9KKp0h5",
				"54b7a427f-2a22-412d-b12e-1abd7cf46532c",
				"f18b538d1be903b6a6f056435b171589caf36bf2");
		System.out.println(token);
	}

	private TokenRequest getTokenRequest() throws URISyntaxException {
		TokenRequest tknRequest = new TokenRequest(new URI("/oauth/token"), new URI("/oauth/authorize"));
		tknRequest.setClientId("tims.credential.enrollment");
		tknRequest.setClientSecret("K0#726Gh9KKp0h5");
		tknRequest.setGrantType(GrantType.PASSWORD);
		tknRequest.setUsername("54b7a427f-2a22-412d-b12e-1abd7cf46532c");
		tknRequest.setPassword("f18b538d1be903b6a6f056435b171589caf36bf2");
		return tknRequest;
	}

	@Test
	public void testRevoke() throws Exception {
		// NOTE: Only revocable tokens will work here, else get a 404
		// this is delete from database of CF in revocable_tokens table
		String token = "8d75299c787a4da7bc07f86f61f54204";
		operations = getConnectionForTokenOperations().tokenOperations();
		operations.revokeToken(token);
	}

	public void checkToken(String tokenAsStr) {

		JWTParser k = new JWTParser();
		Payload jwt = k.parsePayload(tokenAsStr);
		System.out.println("pload  " + jwt.getExpiresAt());

		assertThat(jwt, is(notNullValue()));
		assertThat(jwt.getExpiresAt(), is(instanceOf(Date.class)));
		Date expectedDate = new Date();
		assertThat(jwt.getExpiresAt(), DateMatchers.after(expectedDate));

		assertThat(jwt.getSubject(), is(notNullValue()));
		assertThat(jwt.getIssuer(), is(notNullValue()));
		assertThat(jwt.getClaims(), is(notNullValue()));
		assertThat(jwt.getClaims(), is(instanceOf(Map.class)));
		assertThat(jwt.getClaims().get("sub"), is(notNullValue()));
		assertThat(jwt.getClaims().get("email").asString(), is("enrollmentadministrator@tims.com"));
		assertThat(jwt.getClaims().get("user_id"), is(notNullValue()));
		assertThat(jwt.getClaims().get("user_name").asString(), is("54b7a427f-2a22-412d-b12e-1abd7cf46532c"));
		assertThat(jwt.getClaims().get("origin").asString(), is("uaa"));
		assertThat(jwt.getClaims().get("client_id").asString(), is("tims.credential.enrollment"));
		assertThat(jwt.getClaims().get("grant_type").asString(), is("password"));
		System.out.println("validation pass");
	}

	@Test
	public void testCheckToken() throws Exception {

		String token = "eyJhbGciOiJIUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiIxYWZhZjlkMWFiY2Y0NGMzODUzMjUwNDJmZjliMzNkMSIsInN1YiI6ImJmN2Q4ODAzLTk5MWUtNDI1ZS1hNGMwLWEzZjcxNDU5NTU4ZSIsInNjb3BlIjpbInVhYS51c2VyIl0sImNsaWVudF9pZCI6InRpbXMuY3JlZGVudGlhbC5lbnJvbGxtZW50IiwiY2lkIjoidGltcy5jcmVkZW50aWFsLmVucm9sbG1lbnQiLCJhenAiOiJ0aW1zLmNyZWRlbnRpYWwuZW5yb2xsbWVudCIsImdyYW50X3R5cGUiOiJwYXNzd29yZCIsInVzZXJfaWQiOiJiZjdkODgwMy05OTFlLTQyNWUtYTRjMC1hM2Y3MTQ1OTU1OGUiLCJvcmlnaW4iOiJ1YWEiLCJ1c2VyX25hbWUiOiI1NGI3YTQyN2YtMmEyMi00MTJkLWIxMmUtMWFiZDdjZjQ2NTMyYyIsImVtYWlsIjoiZW5yb2xsbWVudGFkbWluaXN0cmF0b3JAdGltcy5jb20iLCJhdXRoX3RpbWUiOjE1MTE1MTc4NjgsInJldl9zaWciOiI5ZjhhMzc0ZiIsImlhdCI6MTUxMTUxNzg2OCwiZXhwIjoxNTExNjA0MjY4LCJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjgwODAvdWFhL29hdXRoL3Rva2VuIiwiemlkIjoidWFhIiwiYXVkIjpbInVhYSIsInRpbXMuY3JlZGVudGlhbC5lbnJvbGxtZW50Il19.2FuIuHNJqCQ4T-B6BqLlLvyyOYuUdXr5llQmINT0Qks";
		operations = getConnectionForTokenOperations().tokenOperations();
		String json = operations.checkToken(token,"tims.credential.enrollment","K0#726Gh9KKp0h5");

		checkToken(json);

	}

}
