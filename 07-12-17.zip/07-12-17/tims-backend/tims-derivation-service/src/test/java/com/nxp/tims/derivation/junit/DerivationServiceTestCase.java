package com.nxp.tims.derivation.junit;

import java.io.IOException;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.nxp.tims.app.request.response.DerivationServiceRequest;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DerivationServiceTestCase {
	
	private final String CREATE_TOKEN_URL = "http://localhost:8090/timsDI/createToken";
	
	@Test
	public void test_method_1() throws IOException {
		ClientConfig configuration = new ClientConfig();
		configuration.property(ClientProperties.CONNECT_TIMEOUT, 5000);
		configuration.property(ClientProperties.READ_TIMEOUT, 5000);
		
		Client addClient = ClientBuilder.newClient(configuration);
		
		DerivationServiceRequest diManagementRequest = new DerivationServiceRequest();
		
		WebTarget base = addClient.target(CREATE_TOKEN_URL);
		Response response = base.request(MediaType.APPLICATION_JSON).post(Entity.json(diManagementRequest));
		String responseString = response.readEntity(String.class);
		System.out.println(responseString);
	}
}
