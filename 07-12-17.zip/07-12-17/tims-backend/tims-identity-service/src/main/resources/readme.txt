-Dspring.profiles.active=dev 


http://localhost:8080/v2/api-docs
http://localhost:8080/swagger-resources
http://localhost:8080/swagger-ui.html


java -jar  -Dspring.profiles.active=prod build/libs/TIMS-UserManagementService-0.1.0.jar


gradlew build -x test




delete from tims.enrolled_devices
delete from tims.derived_identites
delete from tims.enrolled_certificates


select * from tims.enrolled_certificates

select * from tims.enrolled_devices

select * from tims.derived_identites

delete from public.schema_version

commit

