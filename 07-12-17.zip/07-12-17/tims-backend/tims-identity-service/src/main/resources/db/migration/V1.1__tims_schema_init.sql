
SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP SCHEMA IF EXISTS tims CASCADE;
DROP ROLE IF EXISTS tims_owner;

CREATE SCHEMA tims;


CREATE ROLE tims_owner WITH
NOLOGIN
NOSUPERUSER
INHERIT
NOCREATEDB
NOCREATEROLE
NOREPLICATION;

ALTER SCHEMA tims OWNER TO tims_owner;

COMMENT ON SCHEMA tims IS 'standard public schema';


CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = tims, pg_catalog;
SET default_tablespace = '';
SET default_with_oids = false;


CREATE TABLE derived_identites (
    created_time timestamp without time zone,
    enrolled_certificates_id bigint,
    origin_hash character varying(255),
    uu_id uuid,
    id bigint NOT NULL,
    token_hash character varying(2048),
    derived_identity character varying(2048),
    enrolled_application_id bigint
);


ALTER TABLE derived_identites OWNER TO tims_owner;


CREATE TABLE enrolled_applications (
    id bigint NOT NULL,
    application_name character varying(100),
    created_on timestamp without time zone,
    created_by character varying(50),
    last_modified timestamp without time zone,
    last_modified_by character varying(50),
    comments character varying(255),
    enrollment_status smallint,
    uu_id uuid
);


ALTER TABLE enrolled_applications OWNER TO tims_owner;

 

CREATE TABLE enrolled_certificates (
    id bigint NOT NULL,
    serial_number character varying(255) NOT NULL,
    issuer_dn character varying(255) NOT NULL,
    fingerprint character varying(255),
    ocsp_url character varying(255),
    comments character varying(255),
    created_date timestamp without time zone,
    last_modified_date timestamp without time zone,
    enrollment_status smallint,
    uu_id uuid,
    issuerNameHash character varying(255),
    issuerKeyHash character varying(255),
    hashAlgorithm character varying(255)
);


ALTER TABLE enrolled_certificates OWNER TO tims_owner;

 

CREATE TABLE enrolled_devices (
    device_identifier character varying NOT NULL,
    device_os character varying(50),
    device_type character varying(50),
    enrolled_application_id bigint,
    enrolled_certificates_id bigint,
    comments character varying(255),
    id bigint NOT NULL,
    uu_id uuid
);


ALTER TABLE enrolled_devices OWNER TO tims_owner;

 

CREATE TABLE enrollment_status (
    id smallint NOT NULL,
    status character varying(50),
    description character varying(255)
);


ALTER TABLE enrollment_status OWNER TO tims_owner;

 

CREATE SEQUENCE seq_derived_identities
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999
    CACHE 5;


ALTER TABLE seq_derived_identities OWNER TO tims_owner;

 

CREATE SEQUENCE seq_enrolled_applications
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999
    CACHE 5;


ALTER TABLE seq_enrolled_applications OWNER TO tims_owner;

 

CREATE SEQUENCE seq_enrolled_certificates
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999
    CACHE 5;


ALTER TABLE seq_enrolled_certificates OWNER TO tims_owner;

 

CREATE SEQUENCE seq_enrolled_devices
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999
    CACHE 5;


ALTER TABLE seq_enrolled_devices OWNER TO tims_owner;

 

CREATE SEQUENCE seq_enrollment_status
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 9999999999
    CACHE 1;


ALTER TABLE seq_enrollment_status OWNER TO tims_owner;

   

SELECT pg_catalog.setval('seq_derived_identities', 1, false);


 

SELECT pg_catalog.setval('seq_enrolled_applications', 1, false);

 

SELECT pg_catalog.setval('seq_enrolled_certificates', 1, false);

 

SELECT pg_catalog.setval('seq_enrolled_devices', 1, false);

 

SELECT pg_catalog.setval('seq_enrollment_status', 6, true);



ALTER TABLE ONLY derived_identites
    ADD CONSTRAINT derived_identites_derived_identity_key UNIQUE (derived_identity);

 

ALTER TABLE ONLY derived_identites
    ADD CONSTRAINT derived_identites_pkey PRIMARY KEY (id);

 

ALTER TABLE ONLY derived_identites
    ADD CONSTRAINT derived_identites_uu_id_key UNIQUE (uu_id);


 

ALTER TABLE ONLY enrolled_applications
    ADD CONSTRAINT enrolled_applications_application_name_key UNIQUE (application_name);

 

ALTER TABLE ONLY enrolled_applications
    ADD CONSTRAINT enrolled_applications_pkey PRIMARY KEY (id);

 

ALTER TABLE ONLY enrolled_certificates
    ADD CONSTRAINT enrolled_certificates_pkey PRIMARY KEY (id);

 

ALTER TABLE ONLY enrolled_certificates
    ADD CONSTRAINT enrolled_certificates_serial_number_issuer_dn_key UNIQUE (serial_number, issuer_dn);


 

ALTER TABLE ONLY enrolled_certificates
    ADD CONSTRAINT enrolled_certificates_uu_id_key UNIQUE (uu_id);

 
ALTER TABLE ONLY enrolled_devices
    ADD CONSTRAINT enrolled_devices_device_identifier_key UNIQUE (device_identifier);


 

ALTER TABLE ONLY enrolled_devices
    ADD CONSTRAINT enrolled_devices_pkey PRIMARY KEY (id);

 

ALTER TABLE ONLY enrollment_status
    ADD CONSTRAINT enrollment_status_pkey1 PRIMARY KEY (id);


 

ALTER TABLE ONLY enrollment_status
    ADD CONSTRAINT enrollment_status_status_key UNIQUE (status);


 

ALTER TABLE ONLY derived_identites
    ADD CONSTRAINT derived_identites_enrolled_application_id_fkey FOREIGN KEY (enrolled_application_id) REFERENCES enrolled_applications(id);

 

ALTER TABLE ONLY derived_identites
    ADD CONSTRAINT derived_identites_enrolled_certificates_id_fkey FOREIGN KEY (enrolled_certificates_id) REFERENCES enrolled_certificates(id);

 

ALTER TABLE ONLY enrolled_applications
    ADD CONSTRAINT enrolled_applications_enrollment_status_fkey FOREIGN KEY (enrollment_status) REFERENCES enrollment_status(id);


 

ALTER TABLE ONLY enrolled_certificates
    ADD CONSTRAINT enrolled_certificates_enrollment_status_fkey FOREIGN KEY (enrollment_status) REFERENCES enrollment_status(id);

 

ALTER TABLE ONLY enrolled_devices
    ADD CONSTRAINT enrolled_devices_enrolled_application_id_fkey FOREIGN KEY (enrolled_application_id) REFERENCES enrolled_applications(id);


 

REVOKE ALL ON SCHEMA tims FROM PUBLIC;
REVOKE ALL ON SCHEMA tims FROM tims_owner;
GRANT ALL ON SCHEMA tims TO tims_owner;
GRANT ALL ON SCHEMA tims TO PUBLIC;


