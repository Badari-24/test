-- Add last_modified column in tims.derived_identites table.
ALTER TABLE TIMS.derived_identites ADD COLUMN last_modified timestamp without time zone;
 
commit; 