
INSERT INTO tims.enrollment_status VALUES (1, 'ENROLLED');
INSERT INTO tims.enrollment_status VALUES (2, 'PENDING');
INSERT INTO tims.enrollment_status VALUES (3, 'REVOKED');
INSERT INTO tims.enrollment_status VALUES (4, 'DELETED');
INSERT INTO tims.enrollment_status VALUES (5, 'ACTIVE');
INSERT INTO tims.enrollment_status VALUES (6, 'VALID');
INSERT INTO tims.enrollment_status VALUES (7, 'INVALID');


insert into tims.enrolled_applications values (1,'RP.COM', current_timestamp,
'system',null,null,null,5,null); 


 
commit; 