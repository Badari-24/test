/**
 * Enrolled Certificate Entity class.
 */
package com.nxp.tims.identity.service.data.entity;


import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Badari
 *
 */
@Entity
@Table(name = "enrolled_certificates", schema = "tims")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnrolledCertificateEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/** uuId */
	@Column(name = "uu_id")
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID",strategy = "org.hibernate.id.UUIDGenerator")
	private UUID uuId;

	/** id  */
	@Id
	@Column(name = "id")
	@GeneratedValue(generator = "seq_enrolled_certificates")
	@SequenceGenerator(name = "seq_enrolled_certificates", sequenceName = "tims.seq_enrolled_certificates")
	private Long id;

	
	/** serailNumber */
	@Column(name = "serial_number", nullable = false)
	private String serialNumber;

	
	/** issuerDN */
	@Column(name = "issuer_dn", nullable = false)
	private String issuerDN;
	
	/** fingerPrint */
	@Column(name = "fingerprint")
	private String fingerPrint;

	/** ocspURL */
	@Column(name = "ocsp_url")
	private String ocspURL;
	
	
	/** comments */
	@Column(name = "comments")
	private String comments;
	
	/** createdDate */
	@Column(name = "created_date")
	private Date createdDate;
	
	
	
	/** lastModifiedDate */
	@Column(name = "last_modified_date")
	private Date lastModifiedDate;
	
	/** enrollmentStatus */
	@Column(name = "enrollment_status")
	private int enrollmentStatus;
	
	
	@OneToOne(mappedBy = "enrolledCertificateEntityByDerviedID", cascade = CascadeType.ALL)
	private DerivedIdentitiesEntity derivedIdentitiesEntity;

	
	@OneToOne(mappedBy = "enrolledCertificateEntityByDevice", cascade = CascadeType.ALL)
	private EnrolledDeviceEntity enrolledDeviceEntity;
	
	
	
	
	/** comments */
	@Column(name = "issuernamehash")
	private String issuerNameHash;
	
	
	/** comments */
	@Column(name = "issuerkeyhash")
	private String issuerKeyHash;
	

	/** comments */
	@Column(name = "hashalgorithm")
	private String hashAlgorithm;
	
	
}