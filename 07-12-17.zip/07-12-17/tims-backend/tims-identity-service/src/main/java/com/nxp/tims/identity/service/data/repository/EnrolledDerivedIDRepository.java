/**
 * Repository class to perform Derived Identities Operations in DB.
 */
package com.nxp.tims.identity.service.data.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nxp.tims.identity.service.data.entity.DerivedIdentitiesEntity;

/**
 * 
 * @author Badari
 *
 */
public interface EnrolledDerivedIDRepository extends JpaRepository<DerivedIdentitiesEntity, Long> {

	DerivedIdentitiesEntity findByDerivedIdentity(String id);
	
	DerivedIdentitiesEntity findByUuId(UUID id);
	
	DerivedIdentitiesEntity findById(Long id);
	
	DerivedIdentitiesEntity findByTokenHash(String tokenHash);
	
}
