/**
 * This class exposes application services as REST services. 
 */
package com.nxp.tims.identity.service.controller;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response.Status;

import org.bouncycastle.cert.X509CertificateHolder;
import org.dozer.Mapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nxp.tims.app.external.request.response.BaseResponse;
import com.nxp.tims.app.external.request.response.EnrollmentCertifcateResponseEnum;
import com.nxp.tims.app.external.request.response.EnrollmentRequest;
import com.nxp.tims.app.external.request.response.EnrollmentResponse;
import com.nxp.tims.app.external.request.response.IdentityRevokeRequest;
import com.nxp.tims.app.external.request.response.IdentityRevokeResponse;
import com.nxp.tims.app.external.request.response.IdentityRevokeResponseEnum;
import com.nxp.tims.app.external.request.response.ValidateIdentityRequest;
import com.nxp.tims.app.external.request.response.ValidateIdentityResponse;
import com.nxp.tims.app.external.request.response.ValidateIdentityResponseEnum;
import com.nxp.tims.app.request.response.DerivationServiceRequest;
import com.nxp.tims.app.request.response.DerivationServiceResponse;
import com.nxp.tims.app.request.response.DerivationServiceResponseStatusEnum;
import com.nxp.tims.app.request.response.EnrollServiceResponse;
import com.nxp.tims.app.request.response.ValidateCertificateRequest;
import com.nxp.tims.app.request.response.ValidateCertificateResponse;
import com.nxp.tims.app.request.response.ValidationServiceResponseStatusEnum;
import com.nxp.tims.identity.service.data.entity.DerivedIdentitiesEntity;
import com.nxp.tims.identity.service.data.entity.EnrolledCertificateEntity;
import com.nxp.tims.identity.service.data.model.EnrolledCertificates;
import com.nxp.tims.identity.service.exception.TimsException;
import com.nxp.tims.identity.service.rest.IdentityRestService;
import com.nxp.tims.identity.service.util.EnrollmentStatusEnum;
import com.nxp.tims.identity.service.util.IdentityConstants;
import com.nxp.tims.identity.service.util.IdentityUtil;

import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author Badari
 *
 */
@RestController
public class IdentityServiceController {

	/** Logger for this class */
	private static final Logger LOGGER = LoggerFactory.getLogger(IdentityServiceController.class);

	/** Injecting CredManagment Service to this class */
	@Autowired
	private IdentityRestService identityManagementService;

	@Autowired
	private Mapper mapper;

	/**
	 * Enrolls User Identity
	 * 
	 * Method Flow will be as follows.
	 * 
	 * 
	 * @param certificate
	 * @return
	 */
	@ApiOperation(value = "Enroll User identity", notes = "Enroll User identity", response = String.class)
	@RequestMapping(method = RequestMethod.POST, value = IdentityConstants.ENROLL_URL, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public BaseResponse enroll(@RequestBody EnrollmentRequest enrollmentCertificateRequest,
			@Context final HttpServletResponse response) {
		LOGGER.debug("CredManagementController entered into enroll() method");

 
		try {

			IdentityUtil.validateRequest(enrollmentCertificateRequest);

			X509CertificateHolder x509Certificate = IdentityUtil
					.convertToX509Certificate(enrollmentCertificateRequest.getCredential());
			if (IdentityUtil.isValidCertifcate(x509Certificate)) {
				ValidateCertificateRequest validateCertificateRequest = mapper.map(enrollmentCertificateRequest,
						ValidateCertificateRequest.class);
				ValidateCertificateResponse validateCertificateServiceResponse = identityManagementService
						.validateCertificate(validateCertificateRequest);
				if (validateCertificateServiceResponse != null
						&& validateCertificateServiceResponse.getValidationServiceResponseStatus() != null
						&& validateCertificateServiceResponse.getValidationServiceResponseStatus().name()
								.equals(ValidationServiceResponseStatusEnum.OCSP_VALIDATION_SUCCESS.name())) {

					
					DerivationServiceResponse diManagementServiceResponse=null;
					DerivationServiceRequest diManagementRequest=null; 
					EnrollServiceResponse enrollDIResponse = null; 
					try {
						
						// verify certificate already enrolled flow - start
						EnrolledCertificates enrolledCertificates = 
								identityManagementService.verifyCertificateEnrolled(enrollmentCertificateRequest, validateCertificateServiceResponse);
						if (enrolledCertificates.isAlreadyEnrolled()){
							// create new token and update new token in DB and skip normal enrollment process
							LOGGER.info("Certificate is already enrolled in TIMS, creating new token");
							EnrolledCertificateEntity entity = mapper.map(enrolledCertificates, EnrolledCertificateEntity.class);
							DerivationServiceRequest derivationServiceRequest = new DerivationServiceRequest();
							derivationServiceRequest.setIdentityId(entity.getDerivedIdentitiesEntity().getUuId().toString());
							derivationServiceRequest.setDeviceId(entity.getEnrolledDeviceEntity().getId().toString());
							derivationServiceRequest.setFingerPrint(validateCertificateServiceResponse.getFingerPrint());
							DerivationServiceResponse derivationServiceResponse = identityManagementService.createNewTokenForExistingUser(derivationServiceRequest);
							if (derivationServiceResponse != null && derivationServiceResponse.getDiServiceResponseStatus()
									.name().equals(DerivationServiceResponseStatusEnum.CREATED.toString())) {
								identityManagementService.updateDerivedIdentityDetails(derivationServiceRequest.getIdentityId(),derivationServiceResponse.getDerivedIdentity(),
										entity.getDerivedIdentitiesEntity().getId());
								EnrollmentResponse enrollmentResponse = new EnrollmentResponse();
								enrollmentResponse
								.setEnrollmentStatus(EnrollmentCertifcateResponseEnum.ENROLLED);
								enrollmentResponse.setDerivedIdentity(derivationServiceResponse.getDerivedIdentity());
								enrollmentResponse.setTokenHash(derivationServiceResponse.getTokenHash());
								response.setStatus(HttpServletResponse.SC_CREATED);
								LOGGER.info("New token has been updated for existing user");
								return enrollmentResponse;
								
							} else {
								throw new TimsException("DI SERVICE RETURNED FAILURE INDICATION. failed!!");
							}
						}
						// verify certificate already enrolled flow - end
						
						// First time enrollment flow - start
						enrollDIResponse = identityManagementService.enrollDerivedIdentity(enrollmentCertificateRequest,
								validateCertificateServiceResponse);

						diManagementRequest = new DerivationServiceRequest();
						diManagementRequest.setIdentityId(enrollDIResponse.getIdentityId().toString());
						diManagementRequest.setDeviceId(enrollmentCertificateRequest.getDeviceDetails().getId());
						diManagementRequest.setFingerPrint(validateCertificateServiceResponse.getFingerPrint());
						diManagementServiceResponse = identityManagementService
								.createToken(diManagementRequest);
					} catch (Exception e) {
						e.printStackTrace();
						throw new TimsException("ENROLLED FAILED!!");
					}
					
					
					if (diManagementServiceResponse != null && diManagementServiceResponse.getDiServiceResponseStatus()
							.name().equals(DerivationServiceResponseStatusEnum.CREATED.toString())) {
						identityManagementService.updateDerivedIdentityDetails(diManagementRequest.getIdentityId(),diManagementServiceResponse.getDerivedIdentity(),
								enrollDIResponse.getId());
						EnrollmentResponse enrollmentResponse = new EnrollmentResponse();
						enrollmentResponse
						.setEnrollmentStatus(EnrollmentCertifcateResponseEnum.ENROLLED);
						enrollmentResponse.setDerivedIdentity(diManagementServiceResponse.getDerivedIdentity());
						enrollmentResponse.setTokenHash(diManagementServiceResponse.getTokenHash());
						response.setStatus(HttpServletResponse.SC_CREATED);
						LOGGER.info("ENROLLED SUCCESSFULLY");
						return enrollmentResponse;
						
					} else {
						throw new TimsException("DI SERVICE RETURNED FAILURE INDICATION. failed!!");
					}
				} else {
					throw new TimsException("Validation service --> OCSP Validation is failed !!");
				}
			} else {
				throw new TimsException("x509 Basic validation is failed!!");
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.debug("Exist from : CredManagementController create() method");
		response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		return IdentityUtil.returnErrorResponse(Status.BAD_REQUEST.getStatusCode(), "", "");
	}

	/**
	 * Revokes User Identity    
	 * 
	 * @return Response
	 */
	@ApiOperation(value = "Revoke User Identity", notes = "Revoke User Identity ", response = String.class)
	@RequestMapping(method = RequestMethod.PUT, value = IdentityConstants.REVOKE_DI_URL, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public BaseResponse revokeDerivedIdentity(@RequestBody IdentityRevokeRequest identityRevokeRequest,
			@Context final HttpServletResponse response) {
		
		try {
			
			boolean isValidRequest =false; 
			if(identityRevokeRequest!=null){
				
				if( (identityRevokeRequest.getDerivedIdentity()!=null && identityRevokeRequest.getDerivedIdentity().trim().length() > 0) ||
						(identityRevokeRequest.getTokenHash()!=null && identityRevokeRequest.getTokenHash().trim().length() > 0) ){
					isValidRequest=true; 
				}
				
			}
			
		
			if(isValidRequest){
				boolean success = identityManagementService.revokeDerivedIdentity(identityRevokeRequest);
				if(success)
				{
					LOGGER.info("REVOKED SUCCESSFULLY ");
					IdentityRevokeResponse diRevokeResponse = new IdentityRevokeResponse();
					diRevokeResponse.setRevokedStatus(IdentityRevokeResponseEnum.REVOKED);
					return diRevokeResponse;	
				}else{
					throw new TimsException("Revoke request failed");
				}		
			}else{
				throw new TimsException("Invalid Request, required attributed are missing");
			}
		
			
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage(), e);
		}
		response.setStatus(HttpServletResponse.SC_BAD_REQUEST); 
		return IdentityUtil.returnErrorResponse(Status.BAD_REQUEST.getStatusCode(), "", "");
	}


	/**
	 * Validate Original Certificate.
	 * 
	 * @return
	 */
//	@ApiOperation(value = "Validate Original Certificate", notes = "Requires Certificate", response = String.class)
//	@RequestMapping(method = RequestMethod.POST, value = CredentialManagementConstants.VALIDATE_ORIGINAL_URL, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//	public Response validateOriginalCertificate() {
//		// TODO : Implementation is pending
//		return Response.status(Status.OK).build();
//	}

	/**
	 * Validate Derived Identity.
	 * 
	 * @return
	 */
	@ApiOperation(value = "Validate Derived Identity", notes = "Requires Identity Token", response = String.class)
	@RequestMapping(method = RequestMethod.POST, value = IdentityConstants.VALIDATE_IDENTITY, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public BaseResponse validateIdentity(@RequestBody ValidateIdentityRequest validateIdentityRequest,
			@Context final HttpServletResponse response) {
		
		try {
		boolean isValidRequest =false; 
		if(validateIdentityRequest!=null){
			if( (validateIdentityRequest.getDerivedIdentity()!=null && validateIdentityRequest.getDerivedIdentity().trim().length() > 0)){
				isValidRequest=true; 
			}
			
		}
		
		if(isValidRequest){
			DerivedIdentitiesEntity derivedIdentitiesEntity  = identityManagementService.fetchDerivedIdentityFromDB(validateIdentityRequest);
			if(derivedIdentitiesEntity!=null && 
					derivedIdentitiesEntity.getEnrolledCertificateEntityByDerviedID().getEnrollmentStatus() ==
					EnrollmentStatusEnum.ENROLLED.id())
			{
				ValidateIdentityResponse validateIdentityResponse = new ValidateIdentityResponse();
				validateIdentityResponse.setStatus(ValidateIdentityResponseEnum.SUCCESS);
				return validateIdentityResponse;	
			}else{
				throw new TimsException("Check validateIdentity failed");
			}		
		}else{
			throw new TimsException("Invalid validateIdentity Request, required attributed are missing");
		}
		
		
		
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage(), e);
		}
		response.setStatus(HttpServletResponse.SC_BAD_REQUEST); 
		return IdentityUtil.returnErrorResponse(Status.BAD_REQUEST.getStatusCode(), "", "");
	 
	}
	
	 @RequestMapping("/")
	    public String rootindex() {
	        return "Root::Identity Service is Running!!";
	    }

}