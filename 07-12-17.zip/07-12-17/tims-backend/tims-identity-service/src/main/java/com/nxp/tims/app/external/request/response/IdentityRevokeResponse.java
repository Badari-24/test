package com.nxp.tims.app.external.request.response;

import lombok.Data;


import lombok.NoArgsConstructor;


/**
 * 
 * @author Suresh
 *
 */
@Data
@NoArgsConstructor
public class IdentityRevokeResponse extends BaseResponse{
	/*  Revoked Status */
  private IdentityRevokeResponseEnum revokedStatus;
}
