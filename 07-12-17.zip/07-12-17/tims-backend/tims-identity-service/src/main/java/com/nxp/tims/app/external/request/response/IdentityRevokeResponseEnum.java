package com.nxp.tims.app.external.request.response;


/**
 * 
 * @author Suresh
 *
 */
//This is Enumeration object and contains Revoked and Failed values. 
public enum IdentityRevokeResponseEnum {

	REVOKED(1),FAILED(-1);
	
	/* Id */
	private long id;
	
	/* Constructor */
	IdentityRevokeResponseEnum(int id){
		this.id = id; 
	}
	
	/*  Gets ID */
	public long id(){
		return id; 
	}
}
