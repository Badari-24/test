package com.nxp.tims.app.request.response;

import java.util.UUID;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class EnrollServiceResponse {
	/** Identity ID */
	private UUID identityId;
	/** id **/
	private Long id; 

}
