/**
 * class to hold enrolled device entries from database.
 */
package com.nxp.tims.identity.service.data.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Badari
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnrolledDevices implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/** deviceId */
	private String deviceId;
	
	/** deviceOS */
	private String deviceOS;
	
	/** deviceType */
	private String deviceType;
	
	/** applicationId */
	private int applicationId;
	
	/** enrolledCertificateId */
	private int enrolledCertificateId;
	
	/** comments */
	private String comments; 
	
	/** tokenId */
	private String tokenId;
	
	/** tokenHash */
	private String tokenHash;
	
	/** originHash */
	private String originHash;

}
