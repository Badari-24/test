package com.nxp.tims.app.request.response;

import com.nxp.tims.app.external.request.response.BaseResponse;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class ValidateCertificateResponse extends BaseResponse{
	private String serialNo;
	private String issuerDN;
	private String hashAlogorithm;
	private String issuerKeyHash;
	private String issuerNameHash; 
	private String ocspUrl;
	private String fingerPrint; 
	private ValidationServiceResponseStatusEnum validationServiceResponseStatus;
}
