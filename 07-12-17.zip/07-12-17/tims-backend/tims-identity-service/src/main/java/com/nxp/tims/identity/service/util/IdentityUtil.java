/**
 * Util class to generate hash password.
 * 
 */
package com.nxp.tims.identity.service.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.Security;
import java.util.Calendar;
import java.util.Date;

import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.x509.Certificate;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.digests.SHA512Digest;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Base64;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.nxp.tims.app.external.request.response.BaseResponse;
import com.nxp.tims.app.external.request.response.EnrollmentRequest;
import com.nxp.tims.app.external.request.response.EnrollmentResponse;
import com.nxp.tims.app.request.response.DerivationServiceResponse;
import com.nxp.tims.app.request.response.ValidateCertificateResponse;
import com.nxp.tims.identity.service.exception.ErrorInfo;

/**
 * 
 * @author Suresh
 *
 */
public class IdentityUtil {
	
	/** Logger for this class */
	private static final Logger LOGGER = LoggerFactory.getLogger(IdentityUtil.class);

	/**
	 * password hashing implementation.
	 * 
	 * @param input
	 * @return
	 */
	public static String bouncyCastleHash(String plainString) {
		try {
			Security.addProvider(new BouncyCastleProvider());

			// instantiate the BouncyCastle digest directly.
			Digest messageDigest = new SHA512Digest();

//			byte[] hashedString = messageDigest.digest(plainString.getBytes());
//			return hashedString;
		} catch (Exception e) {
		}
		return null;

	}
	// FirstName, LastName, email and token
	
	
	public static EnrollmentResponse getEnrollmentCertifcateResponse(String responseString){
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			JSONObject jsonObject = new JSONObject(responseString);
			String entityString = jsonObject.getString(IdentityConstants.ENTITY);
			return objectMapper.readValue(entityString, EnrollmentResponse.class);
		}catch(Exception e){
			e.printStackTrace();	
		}
		return null;
	}
	
	public static ValidateCertificateResponse getValidateCertificateResponse(String responseString){
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			JSONObject jsonObject = new JSONObject(responseString);
			String entityString = jsonObject.getString(IdentityConstants.ENTITY);
			return objectMapper.readValue(entityString, ValidateCertificateResponse.class);
		}catch(Exception e){
			e.printStackTrace();	
		}
		return null;
	}
	
	public static DerivationServiceResponse getDIManagementResponse(String responseString){
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			JSONObject jsonObject = new JSONObject(responseString);
			String entityString = jsonObject.getString(IdentityConstants.ENTITY);
			return objectMapper.readValue(entityString, DerivationServiceResponse.class);
		}catch(Exception e){
			e.printStackTrace();	
		}
		return null;
	}
	
	/**
	 * Generates a X509 Certificate object
	 *
	 * @param  X509 Certificate in the form byte Stream
	 * @return  X509 Certificate object
	 */
	public static X509CertificateHolder convertToX509Certificate(String certificate) {

		ByteArrayInputStream bIn = new ByteArrayInputStream(Base64
				.decode(certificate));
		@SuppressWarnings("resource")
		ASN1InputStream aIn = new ASN1InputStream(bIn);
		ASN1Sequence seq = null;
		try {
			seq = (ASN1Sequence) aIn.readObject();
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}
		return new X509CertificateHolder(Certificate.getInstance(seq));
	}
	
	public static boolean isValidCertifcate(X509CertificateHolder x509Certificate)
	{
		if (x509Certificate != null && x509Certificate.getNotAfter() != null)
		{
			Date today = Calendar.getInstance().getTime();
			Date validTo = x509Certificate.getNotAfter();
			if (today.after(validTo)){
				//temporarily true for testing
				return true; 
			}else{
				return true; 
			}
		}

		return true; 
	}
	
	/**
	 * Common method to send error response.
	 * 
	 * @param errorCode
	 * @param businessMessage
	 * @param type
	 * @return
	 */
	public static BaseResponse returnErrorResponse(int errorCode, String businessMessage, String type) {
		BaseResponse baseResponse = new BaseResponse();
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setCode(errorCode);
		errorInfo.setMessage("BADREQUEST");
		errorInfo.setType(type);
		baseResponse.setErrorInfo(errorInfo);
		
		return baseResponse;
	}
	
	 
	
	public  static java.util.UUID getUUID(){
		return java.util.UUID.randomUUID();
	}
	
	public static long getRelayingPartyId(RelayingPartyEnum relayingParty){
		return Long.parseLong(relayingParty.toString());
	}
	
 
	
	public static java.util.Date getDate(){
		return new Date();
	}

//	public static String digestToken(String plainText){
//		//String plainText = "text" + "salt";
//		byte[] hash=null;
//		try {
//			MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
//			hash = messageDigest.digest( plainText.getBytes() );	
//		}catch(Exception e){
//			e.printStackTrace();
//		}
//		return new String(hash);  
//	}
	
	

	public static void validateRequest(EnrollmentRequest enrollmentCertificateRequest) {
		Assert.notNull(enrollmentCertificateRequest, "ExternalEnrollmentCertificateRequest object can't  be null!");
		Assert.notNull(enrollmentCertificateRequest.getAppId(), "App ID can't  be null!");
		
		Assert.notNull(enrollmentCertificateRequest.getCredential(), "Certificate Contents can't  be null!");
		Assert.notNull(enrollmentCertificateRequest.getDeviceDetails(), "DeviceDetails can't  be null!");
		Assert.notNull(enrollmentCertificateRequest.getUserDetails(), "UserDetails can't  be null!");
		Assert.notNull(enrollmentCertificateRequest.getUserDetails().getFirstName(), "UserDetails.FirstName can't  be null!");
		Assert.notNull(enrollmentCertificateRequest.getUserDetails().getLastName(), "UserDetails.LastName can't  be null!");
		Assert.notNull(enrollmentCertificateRequest.getDeviceDetails().getId(), "DeviceDetails.id can't  be null!");
		
		Assert.hasLength(enrollmentCertificateRequest.getAppId().trim(), "AppID should not be empty");
		Assert.hasLength(enrollmentCertificateRequest.getCredential().trim(), "Certificate Contents should not be empty");
		Assert.hasLength(enrollmentCertificateRequest.getDeviceDetails().getId().trim(), "Device ID should not be empty");
		Assert.hasLength(enrollmentCertificateRequest.getUserDetails().getFirstName().trim(), "First Name should not be empty");
		Assert.hasLength(enrollmentCertificateRequest.getUserDetails().getLastName().trim(), "Last Name should not be empty");
		
	}
	
}
