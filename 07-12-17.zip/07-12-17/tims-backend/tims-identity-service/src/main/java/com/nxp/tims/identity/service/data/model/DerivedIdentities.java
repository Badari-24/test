/**
 * class to hold Derived Identities from database. 
 * 
 */
package com.nxp.tims.identity.service.data.model;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Badari
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DerivedIdentities implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**uaaId */
	private String uaaId;
	
	/**createdTime */
	private Timestamp createdTime;
	
	/**expirtyTime */
	private Timestamp expirtyTime;
	
	/**enrolledCertId */
	private int enrolledCertId;

}
