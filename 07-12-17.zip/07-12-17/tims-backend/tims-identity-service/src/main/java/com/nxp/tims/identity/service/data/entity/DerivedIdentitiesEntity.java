/**
 * Derived Identity Entity class.
 */
package com.nxp.tims.identity.service.data.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Badari
 *
 */

@Entity
@Table(name = "derived_identites", schema = "tims")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DerivedIdentitiesEntity implements Serializable {
//Book
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	@Id
	@Column(name = "id")
	@GeneratedValue(generator = "seq_derived_identities")
	@SequenceGenerator(name = "seq_derived_identities", sequenceName = "tims.seq_derived_identities")
	private Long id;
	
	
	/** uuId */
	@Column(name = "uu_id")
	private UUID uuId;
	
	
	/** createdTime */
	@Column(name = "created_time")
	private Date createdTime;
	
	/** lastModified */
	@Column(name = "last_modified")
	private Date lastModified;

	
	/** originHash */
	@Column(name = "origin_hash")
	private String originHash;

	
	/** tokenHash */
	@Column(name = "token_hash")
	private String tokenHash;


	/** derivedIdentity */
	@Column(name = "derived_identity")
	private String derivedIdentity;
	
	
	/** enrolledApplicationId */
	@Column(name = "enrolled_application_id")
	private Long enrolledApplicationId;
	
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "enrolled_certificates_id")
	private EnrolledCertificateEntity enrolledCertificateEntityByDerviedID;
	
}