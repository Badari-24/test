package com.nxp.tims.app.external.request.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ValidateIdentityRequest extends BaseRequest{

	/*  derived Identity */
	private String derivedIdentity;
	
	 
}
