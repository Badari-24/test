package com.nxp.tims.app.external.request.response;

import lombok.Data;

import lombok.NoArgsConstructor;


/**
 * 
 * @author Suresh
 *
 */
@Data
@NoArgsConstructor
public class EnrollmentResponse extends BaseResponse{
	
	/*  Token Hash */
	private String tokenHash;
	/* Derived Identity */
	private String derivedIdentity;
	/*  Enrollment Status */
	private EnrollmentCertifcateResponseEnum enrollmentStatus;
}
