package com.nxp.tims.identity.service.util;

import java.util.Properties;
import org.bouncycastle.crypto.engines.BlowfishEngine;
import org.bouncycastle.crypto.paddings.PaddedBufferedBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Base64;

public class SecurityUtil extends Properties {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

//	public static void main(String[] args) {
//		String originalString = "fall2008"; // String to be encrypted.
//		String keyString = "secretkey"; // A secret key that is used during
//										// encryption and decryption
//		try {
//			String encryptedString = encrypt(originalString, keyString);
//			System.out.println("Original String: " + originalString);
//			System.out.println("Encrypted String: " + encryptedString);
//			String decryptedString = decrypt(encryptedString, keyString);
//			System.out.println("Decrypted String: " + decryptedString);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//	}
	private static String keyString="TIMS-SecretKey-NXP-0001";
	
	public static String decrypt(String cypherText) throws Exception {
			BlowfishEngine engine = new BlowfishEngine();
			PaddedBufferedBlockCipher cipher = new PaddedBufferedBlockCipher(engine);
			StringBuffer result = new StringBuffer();
			KeyParameter key = new KeyParameter(keyString.getBytes());
			cipher.init(false, key);
			byte out[] = Base64.decode(cypherText);
			byte out2[] = new byte[cipher.getOutputSize(out.length)];
			int len2 = cipher.processBytes(out, 0, out.length, out2, 0);
			cipher.doFinal(out2, len2);
			String s2 = new String(out2);
			for (int i = 0; i < s2.length(); i++) {
				char c = s2.charAt(i);
				if (c != 0) {
					result.append(c);
				}
			}
		System.out.println("decrypt "+ cypherText+",-->"+result);	
		return result.toString();
	}

	public static String encrypt(String plainText)  throws Exception{
		BlowfishEngine engine = new BlowfishEngine();
		PaddedBufferedBlockCipher cipher = new PaddedBufferedBlockCipher(engine);
		KeyParameter key = new KeyParameter(keyString.getBytes());
		cipher.init(true, key);
		byte in[] = plainText.getBytes();
		byte out[] = new byte[cipher.getOutputSize(in.length)];
		int len1 = cipher.processBytes(in, 0, in.length, out, 0);
		cipher.doFinal(out, len1);
		String s = new String(Base64.encode(out));
		System.out.println("encrypt "+ plainText+",-->"+s);
		return s;
	}
}