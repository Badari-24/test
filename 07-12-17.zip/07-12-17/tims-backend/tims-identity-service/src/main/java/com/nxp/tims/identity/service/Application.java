/**
 * This class is to initiate application in spring boot.
 */
package com.nxp.tims.identity.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 
 * @author Badari
 *
 */
@SpringBootApplication
public class Application {
	/**
	 * Method to initialize the application
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
}
