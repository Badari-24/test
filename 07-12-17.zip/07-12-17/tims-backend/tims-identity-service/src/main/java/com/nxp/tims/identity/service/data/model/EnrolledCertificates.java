/**
 * class to hold enrolled Certificate entries from database.
 */
package com.nxp.tims.identity.service.data.model;

import java.io.Serializable;
import java.sql.Timestamp;

import com.nxp.tims.identity.service.data.entity.DerivedIdentitiesEntity;
import com.nxp.tims.identity.service.data.entity.EnrolledDeviceEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Badari
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnrolledCertificates implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** id */
	private int id;
	
	/** serialNumber */
	private String serialNumber;
	
	/** issuerDN */
	private String issuerDN;
	
	/** fingerPrint */
	private String fingerPrint;
	
	/** ocspURL */
	private String ocspURL;
	
	/** derivedIdentity */
	private String derivedIdentity;
	
	/** comments */
	private String comments;
	
	/** createdDate */
	private Timestamp createdDate;
	
	/** lastModifiedDate */
	private Timestamp lastModifiedDate;
	
	/** enrollmentStatus */
	private int enrollmentStatus;
	
	/** alreadyEnrolled */
	private boolean alreadyEnrolled;
	
	/** derivedIdentitiesEntity */
	private DerivedIdentitiesEntity derivedIdentitiesEntity;
	
	/** enrolledDeviceEntity */
	private EnrolledDeviceEntity enrolledDeviceEntity;

}
