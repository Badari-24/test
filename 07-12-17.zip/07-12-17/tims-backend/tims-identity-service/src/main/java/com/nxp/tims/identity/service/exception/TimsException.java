package com.nxp.tims.identity.service.exception;

public class TimsException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TimsException(String message){
		super(message);
	}
}
