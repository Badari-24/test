package com.nxp.tims.identity.service.util;

public enum EnrollmentStatusEnum {

	ENROLLED(1),
	PENDING(2),
	REVOKED(3),
	DELETED(4),
	ACTIVE(5),
	VALID(6),
	INVALID(7);	
	
	
	private int id;
	
	EnrollmentStatusEnum(int id){
		this.id = id; 
	}
	
	public int id(){
		return id; 
	}
}
