/**
 * Repository class to perform Derived Identities Operations in DB.
 */
package com.nxp.tims.identity.service.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nxp.tims.identity.service.data.entity.EnrolledDeviceEntity;

/**
 * 
 * @author Badari
 *
 */
public interface EnrolledDeviceRepository extends JpaRepository<EnrolledDeviceEntity, Long> {

}
