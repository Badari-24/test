package com.nxp.tims.app.external.request.response;


/**
 * 
 * @author Suresh
 *
 */
// 
public enum ValidateIdentityResponseEnum {
	GOOD, BAD,UNKNOWN,SUCCESS
}
