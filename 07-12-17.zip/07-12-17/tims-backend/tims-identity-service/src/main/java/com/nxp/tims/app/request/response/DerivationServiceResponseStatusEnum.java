package com.nxp.tims.app.request.response;

public enum DerivationServiceResponseStatusEnum {

	CREATED(1),FAILED(-1);
	
	private int id;
	
	DerivationServiceResponseStatusEnum(int id){
		this.id = id; 
	}
	
	public int id(){
		return id; 
	}
}
