package com.nxp.tims.app.external.request.response;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Suresh
 *
 */
@Data
@NoArgsConstructor
/* DeviceDetails object contains device specific details */
public class DeviceDetails {
	/* Device Id */
	 private String id;
	 /* Device Operation System */
	 private String os;
	 /* Device Type */
	 private String type;
	 /* Device Name */
	 private String name;
	 /* Device Manufacturer */
	 private String manufacturer;

}
