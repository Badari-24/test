/**
 * Model class for user entity.
 * 
 */
package com.nxp.tims.identity.service.data.model;

import java.io.Serializable;
import java.sql.Date;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Badari
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User implements Serializable {

	private static final long serialVersionUID = 6219555003077040699L;
	
	/** id */
	private UUID id;
	/** firstName */
	private String firstName;
	/** lastName */
	private String lastName;
	/** password */
	private String password;
	/** createdBy */
	private String createdBy;
	/** updatedBy */
	private String updatedBy;
	/** createdAt */
	private Date createdAt;
	/** updatedAt */
	private Date updatedAt;
	/** accessToken */
	private String accessToken;
	/** certificate */
	private String certificate;
	/** serialNo */
	private String serialNo;
	/** userType */
	private UserType userType;
	/** userStatus */
	private UserStatus userStatus;
	/** versionDetails */
	private String versionDetails;
}
