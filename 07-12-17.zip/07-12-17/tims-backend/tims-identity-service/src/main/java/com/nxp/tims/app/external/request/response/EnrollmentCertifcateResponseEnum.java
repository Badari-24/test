package com.nxp.tims.app.external.request.response;

/**
 * 
 * @author Suresh
 *
 */
public enum EnrollmentCertifcateResponseEnum {

	ENROLLED(1),FAILED(-1);
	/* id */ 
	private int id;
	/* Constructor */
	EnrollmentCertifcateResponseEnum(int id){
		this.id = id; 
	}
	/* Gets Id */
	public int id(){
		return id; 
	}
}
