/**
 * Enrollment Status Entity class.
 */
package com.nxp.tims.identity.service.data.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Badari
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "enrollment_status", schema = "tims")

public class EnrollmentStatusEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** id */
	@Id
	@Column(name = "enrollment_status_id", nullable = false)
	private int id;

	/** enrollmentStatusType */
	@Column(name = "enrollment_status_type")
	private String enrollmentStatusType;

	/** enrollmentStatusDesc */
	@Column(name = "enrollment_status_description")
	private String enrollmentStatusDesc;

	@Override
	public String toString() {
		return "EnrollmentStatusEntity [id=" + id + ", enrollmentStatusType=" + enrollmentStatusType
				+ ", enrollmentStatusDesc=" + enrollmentStatusDesc + "]";
	}
}