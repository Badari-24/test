/**
 * Exception Process class
 */
package com.nxp.tims.identity.service.exception;

/**
 * Created by indra.basak on 3/8/17.
 */

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Suresh
 *
 */
@ControllerAdvice
@Slf4j
public class ExceptionProcessor {

	/**
	 * handleDataNotFoundException implementation.
	 * 
	 * @param req
	 * @param ex
	 * @return
	 */
	@ExceptionHandler(DataNotFoundException.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	@ResponseBody
	public ErrorInfo handleDataNotFoundException(HttpServletRequest req,
			DataNotFoundException ex) {
		ErrorInfo info = getErrorInfo(req, HttpStatus.NOT_FOUND);
		info.setMessage(ex.getMessage());

		return info;
	}

	/**
	 * handleIllegalArgException implementation.
	 * 
	 * @param req
	 * @param ex
	 * @return
	 */
	@ExceptionHandler(InvalidSearchException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ResponseBody
	public ErrorInfo handleIllegalArgException(HttpServletRequest req,
			InvalidSearchException ex) {
		ErrorInfo info = getErrorInfo(req, HttpStatus.BAD_REQUEST);
		info.setMessage(ex.getMessage());

		return info;
	}

	/**
	 * getErrorInfo implementation.
	 * 
	 * @param req
	 * @param httpStatus
	 * @return
	 */
	private ErrorInfo getErrorInfo(HttpServletRequest req, HttpStatus httpStatus) {
		ErrorInfo info = new ErrorInfo();
		ServletUriComponentsBuilder builder = ServletUriComponentsBuilder
				.fromServletMapping(req);
	//	info.setPath(builder.path(req.getRequestURI()).build().getPath());
		info.setCode(httpStatus.value());
		info.setType(httpStatus.getReasonPhrase());
		return info;
	}
}
