/**
* This class holds application configuration.  
*/
package com.nxp.tims.identity.service.config;

import java.util.UUID;

import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.dozer.loader.api.TypeMappingOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.nxp.tims.identity.service.interceptor.IdentityServiceInterceptor;
import com.nxp.tims.identity.service.util.UuidBeanFactory;

/**
 * 
 * @author Suresh
 *
 */
@Component
public class IdentityServiceConfiguration extends WebMvcConfigurerAdapter {

    /**
     *  Dozer Implementation.
     *  
     * @return
     */
	@Bean
    public static Mapper getMapper() {
        BeanMappingBuilder builder = new BeanMappingBuilder() {
            protected void configure() {
                mapping(UUID.class, UUID.class, TypeMappingOptions.oneWay(),
                        TypeMappingOptions.beanFactory(
                                UuidBeanFactory.class.getName()));
            }
        };

        DozerBeanMapper mapper = new DozerBeanMapper();
        mapper.addMapping(builder);

        return mapper;
    }
  
    /** Injecting CredManagementInterceptor*/
    @Autowired
	private IdentityServiceInterceptor credManagementInterceptor;

   /**
    * Add Interceptors
    */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(credManagementInterceptor)
          .addPathPatterns("/**/tims/**/");
    }
    
}
