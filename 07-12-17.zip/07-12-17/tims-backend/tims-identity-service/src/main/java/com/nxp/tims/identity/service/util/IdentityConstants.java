/**
 * Constants file for this application.
 */
package com.nxp.tims.identity.service.util;

/**
 * 
 * @author Badari
 *
 */
public final class IdentityConstants {

	/** ENROLL_URL */
	//public static final String ENROLL_URL = "/tims/enrollment";
	public static final String ENROLL_URL = "/tims/identity";
	/** REVOKE_DI_URL */
	//public static final String REVOKE_DI_URL = "/tims/revocation";
	public static final String REVOKE_DI_URL = "/tims/identity";
	
	
	/** VALIDATE_ORIGINAL_URL */
	// public static final String VALIDATE_ORIGINAL_URL = "/tims/validation";
	/** VALIDATE_DI_URL */
	public static final String VALIDATE_IDENTITY = "/tims/identity/validation";
	/** TIMS_PASSWORD_SALT */
	// public static final String TIMS_PASSWORD_SALT = "my-tims-password-text";

	/** ENTITY String */
	public static final String ENTITY = "entity";

	public static final boolean isUniqueValueGenerationRequiredforTesting = false;
}
