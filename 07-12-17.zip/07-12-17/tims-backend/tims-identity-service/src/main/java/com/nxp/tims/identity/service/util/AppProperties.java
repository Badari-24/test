/**
 * 
 */
package com.nxp.tims.identity.service.util;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Badari
 *
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Component
@ConfigurationProperties(prefix = "tims") // prefix app, find user.* values
public class AppProperties {

	/** validateServiceURL */
	private String validateServiceURL;
	
	/** diServiceURL */
	private String diServiceURL;
	
	/** Connection Timeout value */
	private String connectiontimeout;
	
	/** Read Timeout value */
	private String readtimeout;
	 
}