/**
 * class to hold Enrollment status entries from database.
 */
package com.nxp.tims.identity.service.data.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Badari
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnrollmentStatus implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/** enrollmentStatusId */
	private int enrollmentStatusId;
	
	/** enrollmentStatusType */
	private String enrollmentStatusType;
	
	/** enrollmentStatusDescription */
	private String enrollmentStatusDescription;
	

}
