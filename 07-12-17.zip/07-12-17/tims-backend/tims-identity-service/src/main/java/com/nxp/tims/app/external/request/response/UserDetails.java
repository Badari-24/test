package com.nxp.tims.app.external.request.response;

/**
 * 
 * @author Suresh
 *
 */

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
//This objects holds User Details
public class UserDetails {
	
	/* First Name */ 
	private String firstName;
	/* Last Name */
	private String lastName;
	/* Email ID */
	private String emailId;

}
