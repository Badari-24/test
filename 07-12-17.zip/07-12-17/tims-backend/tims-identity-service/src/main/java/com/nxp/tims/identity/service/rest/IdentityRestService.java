/**
ca * Service class for this application.
 */
package com.nxp.tims.identity.service.rest;

import java.util.Date;
import java.util.UUID;

import javax.transaction.Transactional;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.dozer.Mapper;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nxp.tims.app.external.request.response.EnrollmentRequest;
import com.nxp.tims.app.external.request.response.IdentityRevokeRequest;
import com.nxp.tims.app.external.request.response.ValidateIdentityRequest;
import com.nxp.tims.app.request.response.EnrollServiceResponse;
import com.nxp.tims.app.request.response.DerivationServiceRequest;
import com.nxp.tims.app.request.response.DerivationServiceResponse;
import com.nxp.tims.app.request.response.ValidateCertificateRequest;
import com.nxp.tims.app.request.response.ValidateCertificateResponse;
import com.nxp.tims.identity.service.data.entity.DerivedIdentitiesEntity;
import com.nxp.tims.identity.service.data.entity.EnrolledCertificateEntity;
import com.nxp.tims.identity.service.data.entity.EnrolledDeviceEntity;
import com.nxp.tims.identity.service.data.model.EnrolledCertificates;
import com.nxp.tims.identity.service.data.repository.EnrolledCertificateRepository;
import com.nxp.tims.identity.service.data.repository.EnrolledDerivedIDRepository;
import com.nxp.tims.identity.service.exception.DataNotFoundException;
import com.nxp.tims.identity.service.util.AppProperties;
import com.nxp.tims.identity.service.util.EnrollmentStatusEnum;
import com.nxp.tims.identity.service.util.IdentityConstants;
import com.nxp.tims.identity.service.util.IdentityUtil;
import com.nxp.tims.identity.service.util.RelayingPartyEnum;
import com.nxp.tims.identity.service.util.SecurityUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Suresh
 *
 */
@Service
@Slf4j
public class IdentityRestService {

	@Autowired
	private AppProperties timesProperties;

	

	@Autowired
	private EnrolledCertificateRepository enrolledCertificateRepo;

	
	@Autowired
	private EnrolledDerivedIDRepository enrolledDerivedIDRepo;

	@Autowired
	private Mapper mapper;

	/** Logger for this class */
	private static final Logger LOGGER = LoggerFactory.getLogger(IdentityRestService.class);
	
	/**
	 * Create User information in database.
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	public EnrollServiceResponse enrollDerivedIdentity(EnrollmentRequest enrollmentCertifcateRequest,
			ValidateCertificateResponse validateCertificateResponse) throws Exception {
		// validate(request);

		String derivedId = null;

		EnrolledCertificateEntity enrolledCertificateEntity = new EnrolledCertificateEntity();
		enrolledCertificateEntity.setEnrollmentStatus(EnrollmentStatusEnum.ENROLLED.id());// Foreign_key
		enrolledCertificateEntity.setUuId(IdentityUtil.getUUID());// unique

		enrolledCertificateEntity.setIssuerDN(validateCertificateResponse.getIssuerDN());// unique
																							// and
																							// not
																							// null
		enrolledCertificateEntity.setSerialNumber(validateCertificateResponse.getSerialNo());// not
																								// null
		enrolledCertificateEntity.setFingerPrint(validateCertificateResponse.getFingerPrint());

		enrolledCertificateEntity.setOcspURL(validateCertificateResponse.getOcspUrl());
		// enrolledCertificateEntity.setComments("Comments fileds");
		enrolledCertificateEntity.setCreatedDate(IdentityUtil.getDate());

		enrolledCertificateEntity.setHashAlgorithm(validateCertificateResponse.getHashAlogorithm());
		enrolledCertificateEntity.setIssuerKeyHash(validateCertificateResponse.getIssuerKeyHash());
		enrolledCertificateEntity.setIssuerNameHash(validateCertificateResponse.getIssuerNameHash());

		DerivedIdentitiesEntity derivedIdentities = new DerivedIdentitiesEntity();
		derivedIdentities.setCreatedTime(IdentityUtil.getDate());
		derivedIdentities.setUuId(IdentityUtil.getUUID()); // unique id
		derivedIdentities.setEnrolledCertificateEntityByDerviedID(enrolledCertificateEntity); // Foreign
																								// key
		derivedIdentities.setEnrolledApplicationId(RelayingPartyEnum.RP_COM.id()); // Foreign
																					// key

		// derivedIdentities.setOriginHash(diManagementResponse.getOriginHash());
		// derivedIdentities.setTokenHash(diManagementResponse.getDi());
		// String
		// encryptedDIKey=SecurityUtil.encrypt(diManagementResponse.getDi());
		// derivedIdentities.setDerivedIdentity(encryptedDIKey);

		enrolledCertificateEntity.setDerivedIdentitiesEntity(derivedIdentities);

		EnrolledDeviceEntity enrolledDeviceEntity = new EnrolledDeviceEntity();
		enrolledDeviceEntity.setUuId(IdentityUtil.getUUID()); // unique id
		enrolledDeviceEntity.setEnrolledApplicationId(RelayingPartyEnum.RP_COM.id()); // Foreign
																						// key
		enrolledCertificateEntity.setEnrolledDeviceEntity(enrolledDeviceEntity); // Foreign_key
		enrolledDeviceEntity.setEnrolledCertificateEntityByDevice(enrolledCertificateEntity); // Foreign_key

		if (IdentityConstants.isUniqueValueGenerationRequiredforTesting) {
			Date currentdate = new java.util.Date();
			enrolledDeviceEntity.setDeviceId(
					enrollmentCertifcateRequest.getDeviceDetails().getId() + ":TEST:" + currentdate.getTime());
		} else {
			enrolledDeviceEntity.setDeviceId(enrollmentCertifcateRequest.getDeviceDetails().getId());
		}

		enrolledDeviceEntity.setDeviceOS(enrollmentCertifcateRequest.getDeviceDetails().getOs());
		enrolledDeviceEntity.setDeviceType(enrollmentCertifcateRequest.getDeviceDetails().getType());
		// enrolledDeviceEntity.setComments("comments...");

		enrolledCertificateRepo.save(enrolledCertificateEntity);
		// derivedId = encryptedDIKey;

		EnrollServiceResponse enrollDIResponse = new EnrollServiceResponse();
		enrollDIResponse.setId(enrolledCertificateEntity.getDerivedIdentitiesEntity().getId());
		enrollDIResponse.setIdentityId(enrolledCertificateEntity.getDerivedIdentitiesEntity().getUuId());
		return enrollDIResponse;
	}

	public boolean updateDerivedIdentityDetails(String uuid, String derviedId, Long id) throws Exception{

		DerivedIdentitiesEntity derivedIdentitiesEntity = enrolledDerivedIDRepo.findByUuId(UUID.fromString(uuid));
		// DerivedIdentitiesEntity derivedIdentitiesEntity =
		// enrolledDerivedIDRepo.findById(id);

		// derivedIdentitiesEntity.getUuId();
		// derivedIdentitiesEntity.getDerivedIdentity()

		if (derivedIdentitiesEntity != null) {
			derivedIdentitiesEntity.setDerivedIdentity(derviedId);
			derivedIdentitiesEntity.setTokenHash(SecurityUtil.encrypt(derviedId));
			derivedIdentitiesEntity.setLastModified(IdentityUtil.getDate());
			enrolledDerivedIDRepo.save(derivedIdentitiesEntity);
		}

		return true;

	}

	public boolean revokeDerivedIdentity(IdentityRevokeRequest diRevokeRequest) throws Exception {
		// String diKey = SecurityUtil.decrypt(diRevokeRequest.getDerivedId());
		DerivedIdentitiesEntity derivedIdentitiesEntity=null; 
		
		if(diRevokeRequest.getDerivedIdentity()!=null && diRevokeRequest.getDerivedIdentity().trim().length()>0){
		
			derivedIdentitiesEntity = enrolledDerivedIDRepo
					.findByDerivedIdentity(diRevokeRequest.getDerivedIdentity().trim());
		
		}else if(diRevokeRequest.getTokenHash()!=null && diRevokeRequest.getTokenHash().trim().length()>0){
			derivedIdentitiesEntity = enrolledDerivedIDRepo
					.findByTokenHash(diRevokeRequest.getTokenHash().trim());
		}
		 
		if (derivedIdentitiesEntity != null) {
			
			
			if( derivedIdentitiesEntity.getEnrolledCertificateEntityByDerviedID().getEnrollmentStatus()
					== EnrollmentStatusEnum.DELETED.id())
			{
				LOGGER.info("Record is already DELETED STATUS - CAN'T BE REVOKED AGAIN");
				//Already in DELETED Status. No update rerquired. 
				return false;
			}
			
			derivedIdentitiesEntity.getEnrolledCertificateEntityByDerviedID()
					.setEnrollmentStatus(EnrollmentStatusEnum.DELETED.id());
			enrolledDerivedIDRepo.save(derivedIdentitiesEntity);
			return true;
			// derivedIdentitiesRepo.save(derivedIdentities);
		} else {
			return false;
		}
	}
	
	public DerivedIdentitiesEntity fetchDerivedIdentityFromDB(ValidateIdentityRequest validateIdentityRequest) throws Exception {
		// String diKey = SecurityUtil.decrypt(diRevokeRequest.getDerivedId());
		DerivedIdentitiesEntity derivedIdentitiesEntity=null; 
		
		if(validateIdentityRequest.getDerivedIdentity()!=null && validateIdentityRequest.getDerivedIdentity().trim().length()>0){
		
			derivedIdentitiesEntity = enrolledDerivedIDRepo
					.findByDerivedIdentity(validateIdentityRequest.getDerivedIdentity().trim());
		
		} 
		return derivedIdentitiesEntity;
		 
	}
	
	
	
	/**
	 * Verify certificate is already enrolled in DB based on IssuerDN, Serial Number & AppID
	 * if Record exists, update enrollment status to VALID.
	 * else return false
	 * 
	 * @param enrollmentCertifcateRequest
	 * @param validateCertificateResponse
	 * @return true/false
	 * @throws Exception 
	 */
	public EnrolledCertificates verifyCertificateEnrolled(EnrollmentRequest enrollmentCertifcateRequest,
			ValidateCertificateResponse validateCertificateResponse) throws Exception {
		EnrolledCertificates enrolledCertificates = new EnrolledCertificates();
		if (validateCertificateResponse != null && enrollmentCertifcateRequest != null) {
			String issuerDN = validateCertificateResponse.getIssuerDN();
			String serialNumber = validateCertificateResponse.getSerialNo();
			EnrolledCertificateEntity entity = enrolledCertificateRepo.findByIssuerDNAndSerialNumber(issuerDN,
					serialNumber);
			if (entity != null) {
				if (enrollmentCertifcateRequest.getAppId() != null && entity.getEnrolledDeviceEntity() != null 
						&& RelayingPartyEnum.RP_COM.id() == entity.getEnrolledDeviceEntity().getEnrolledApplicationId()) {
					enrolledCertificates = mapper.map(entity, EnrolledCertificates.class);
					enrolledCertificates.setAlreadyEnrolled(true);
					return enrolledCertificates;
				}
			} 
		}
		return enrolledCertificates;
	}

	/**
	 * Update Enrollment status in EnrolledCertificates table.
	 * 
	 * @param id
	 * @param statusId
	 * @throws Exception
	 */
	@Transactional
	public void updateCredentialEnrollmentStatus(Long id, int statusId) throws Exception {
		EnrolledCertificateEntity entity = enrolledCertificateRepo.findOne(id);
		if (entity == null) {
			throw new DataNotFoundException("Certificate with" + id + " not found!");
		}
		entity.setEnrollmentStatus(statusId);
		entity = enrolledCertificateRepo.save(entity);
	}



	/**
	 * Validate certificate with issuer.
	 * 
	 * @param certificateRequestVO
	 * @return
	 */
	public ValidateCertificateResponse validateCertificate(ValidateCertificateRequest validateCertificateRequest) {
		LOGGER.info("Calling Validation service..");
		ClientConfig configuration = new ClientConfig();
		configuration.property(ClientProperties.CONNECT_TIMEOUT, timesProperties.getConnectiontimeout());
		configuration.property(ClientProperties.READ_TIMEOUT, timesProperties.getReadtimeout());

		Client addClient = ClientBuilder.newClient(configuration);
	
		WebTarget base = addClient
				.target(timesProperties.getValidateServiceURL() + "/timsValidation/validateWithIssuer");
		Response response = base.request(MediaType.APPLICATION_JSON).post(Entity.json(validateCertificateRequest));
		String responseString = response.readEntity(String.class);
		ObjectMapper objectMapper = new ObjectMapper();
		ValidateCertificateResponse validateCertificateResponse = null;
		try {
			validateCertificateResponse = objectMapper.readValue(responseString, ValidateCertificateResponse.class);
		} catch (Exception e) {
			LOGGER.error("validateCertificate - "+ e.getMessage());
			e.printStackTrace();
		}

		return validateCertificateResponse;
	}

	/**
	 * Create token by calling DI Management service.
	 * 
	 * @return
	 */
	public DerivationServiceResponse createToken(DerivationServiceRequest diManagementRequest) {
		LOGGER.info("Calling Deriviation service...");
		ClientConfig configuration = new ClientConfig();
		configuration.property(ClientProperties.CONNECT_TIMEOUT, timesProperties.getConnectiontimeout());
		configuration.property(ClientProperties.READ_TIMEOUT, timesProperties.getReadtimeout());

		diManagementRequest.setDeviceId("deviceId");
		Client addClient = ClientBuilder.newClient(configuration);
		WebTarget base = addClient.target(timesProperties.getDiServiceURL() + "/timsDI/createToken");
		Response response = base.request(MediaType.APPLICATION_JSON).post(Entity.json(diManagementRequest));
		String responseString = response.readEntity(String.class);
		
		ObjectMapper objectMapper = new ObjectMapper();
		DerivationServiceResponse diManagementResponse = null;
		try {
			diManagementResponse = objectMapper.readValue(responseString, DerivationServiceResponse.class);
		} catch (Exception e) {
			LOGGER.error("validateCertificate - "+ e.getMessage());
			e.printStackTrace();
		}

		return diManagementResponse;
	}
	
	/**
	 * Create new token for existing user by calling DI Management service.
	 * 
	 * @return
	 */
	public DerivationServiceResponse createNewTokenForExistingUser(DerivationServiceRequest diManagementRequest) {
		LOGGER.info("Calling Deriviation service to get New token");
		ClientConfig configuration = new ClientConfig();
		configuration.property(ClientProperties.CONNECT_TIMEOUT, timesProperties.getConnectiontimeout());
		configuration.property(ClientProperties.READ_TIMEOUT, timesProperties.getReadtimeout());

		diManagementRequest.setDeviceId("deviceId");
		Client addClient = ClientBuilder.newClient(configuration);
		WebTarget base = addClient.target(timesProperties.getDiServiceURL() + "/timsDI/createNewToken");
		Response response = base.request(MediaType.APPLICATION_JSON).post(Entity.json(diManagementRequest));
		String responseString = response.readEntity(String.class);
		
		ObjectMapper objectMapper = new ObjectMapper();
		DerivationServiceResponse diManagementResponse = null;
		try {
			diManagementResponse = objectMapper.readValue(responseString, DerivationServiceResponse.class);
		} catch (Exception e) {
			LOGGER.error("validateCertificate - "+ e.getMessage());
			e.printStackTrace();
		}

		return diManagementResponse;
	}

	/**
	 * check whether original certificate is already enrolled in TIMS database.
	 * 
	 * @return true/false
	 */
	public boolean isOrigCertEnrolled() {
		// TODO : call DB logic to check - implementation
		return true;
	}

	/**
	 * create original credential.
	 */
	public void createOrigCred() {
		// TODO : Implementation
	}

	/**
	 * Enroll device into TIMS database.
	 */
	public void enrollDevice() {
		// TODO : Implementation
	}

	/**
	 * Enroll Application into TIMS database.
	 */
	public void enrollApplication() {
		// TODO : Implementation
	}
}
