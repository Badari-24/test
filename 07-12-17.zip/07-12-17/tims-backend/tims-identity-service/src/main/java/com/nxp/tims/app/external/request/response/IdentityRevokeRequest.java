package com.nxp.tims.app.external.request.response;

import lombok.Data;

import lombok.NoArgsConstructor;


/**
 * 
 * @author Suresh
 *
 */
@Data
@NoArgsConstructor
//Identity Revoke Request 
public class IdentityRevokeRequest extends BaseRequest{
	
	/*  derived Identity */
	private String derivedIdentity;
	
	/*  Token Hash */
	private String tokenHash;
}
