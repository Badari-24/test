/**
 * Repository class to perform Derived Identities Operations in DB.
 */
package com.nxp.tims.identity.service.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nxp.tims.identity.service.data.entity.EnrolledCertificateEntity;

/**
 * 
 * @author Badari
 *
 */
public interface EnrolledCertificateRepository extends JpaRepository<EnrolledCertificateEntity, Long> {
	EnrolledCertificateEntity findByIssuerDNAndSerialNumber(String issuerDN, String serialNumber);

}
