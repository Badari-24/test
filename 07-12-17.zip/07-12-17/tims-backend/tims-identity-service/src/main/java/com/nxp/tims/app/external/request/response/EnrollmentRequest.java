/**
 * This class is to hold X509 Certificate request details
 * and passing it as request in service calls.
 */
package com.nxp.tims.app.external.request.response;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Badari
 *
 */
@Data
@NoArgsConstructor
public class EnrollmentRequest extends BaseRequest {

	/** credential */
	private String credential;
	
	/** deviceDetails */
	private DeviceDetails deviceDetails; 
	
	/** userDetails */
	private UserDetails userDetails;
	
	/** appId */
	private String appId;
	
	/** issueDI */
	private boolean issueDerivedIdentity;
	
}
