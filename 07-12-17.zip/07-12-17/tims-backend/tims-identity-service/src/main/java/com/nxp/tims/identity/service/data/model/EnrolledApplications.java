/**
 * class to hold Enrolled Application entries from database.
 */
package com.nxp.tims.identity.service.data.model;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Badari
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnrolledApplications implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/** id */
	private int id;
	
	/** applicationName */
	private String applicationName;
	
	/** createdOn */
	private Timestamp createdOn;
	
	/** createdBy */
	private String createdBy;
	
	/** lastModified */
	private Timestamp lastModified;
	
	/** lastModifiedBy */
	private String lastModifiedBy;
	
	/** comments */
	private String comments;
	
	/** enrollmentStatus */
	private int enrollmentStatus;

}
