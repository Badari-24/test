/**
 *  Enum values for User Type.
 */
package com.nxp.tims.identity.service.data.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * 
 * @author Suresh
 *
 */
public enum UserType {

	USER(1), SUPERUSER(2), ADMINUSER(3);
	
	private final int type;

	UserType(int type) {
		this.type = type;
	}

	public int getType() {
		return type;
	}

	@JsonCreator
	public static UserType fromValue(String value) {
		return valueOf(value.toUpperCase());
	}
	
	
	@JsonCreator
	public static UserType fromType(int typeVal) {
		for(UserType ut : UserType.values()){
			if(ut.getType() == typeVal){
				return ut;
			}
		}
		
		return null;
	}

	@JsonValue
	public static String toValue(UserType type) {
		return type.name().toLowerCase();
	}
}
