/** 
 * Data Not Found Exception Class
 */
package com.nxp.tims.identity.service.exception;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Suresh
 *
 */
@NoArgsConstructor
@ToString(callSuper = true)
@Getter
@Setter
public class DataNotFoundException extends RuntimeException {
	/**
	 * DataNotFoundException implementation.
	 * @param s
	 */
	public DataNotFoundException(String s) {
		super(s);
	}
}
