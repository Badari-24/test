package com.nxp.tims.app.external.request.response;

import com.nxp.tims.identity.service.exception.ErrorInfo;

import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * 
 * @author Suresh
 *
 */
@Data
@NoArgsConstructor
public class BaseResponse {

	/*  Error Info */
	private ErrorInfo errorInfo;

}
