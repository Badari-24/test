/**
 * Enrolled Application Entity class.
 */
package com.nxp.tims.identity.service.data.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Badari
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "enrolled_applications", schema = "tims")

public class EnrolledApplicationEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@Id
	@Column(name = "id")
	@GeneratedValue(generator = "seq_enrolled_applications")
	@SequenceGenerator(name = "seq_enrolled_applications", sequenceName = "seq_enrolled_applications")
	private int id;

	/** applicationName */
	@Column(name = "application_name")
	private String applicationName;

	/** createdOn */
	@Column(name = "created_on")
	private Date createdOn;
	
	/** createdBy */
	@Column(name = "created_by")
	private String createdBy;

	/** lastModified */
	@Column(name = "last_modified")
	private Date lastModified;
	
	/** lastModifiedBy */
	@Column(name = "last_modified_by")
	private String lastModifiedBy;
	
	/** comments */
	@Column(name = "comments")
	private String comments;
	
	/** enrollmentStatus */
	@Column(name = "enrollment_status")
	private int enrollmentStatus;

 
	
	
}