package com.nxp.tims.identity.service.util;

public enum RelayingPartyEnum {

	RP_COM(1);
	
	private long id;
	
	RelayingPartyEnum(long id){
		this.id = id; 
	}
	
	public long id(){
		return id; 
	}
}
