package com.nxp.tims.app.request.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DerivationServiceRequest {
	  /** device id **/
	  private String deviceId;
	  /** identity id **/
	  private String identityId;
	  /** finger print **/
	  private String fingerPrint;
}
