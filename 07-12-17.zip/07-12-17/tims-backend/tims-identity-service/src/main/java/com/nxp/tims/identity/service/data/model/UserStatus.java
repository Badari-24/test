/**
 * Enum values for User Status
 */
package com.nxp.tims.identity.service.data.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * 
 * @author Suresh
 *
 */
public enum UserStatus {

	ACTIVE(1), INACTIVE(2), DISABLED(3), DELETED(4);

	private final int type;

	UserStatus(int type) {
		this.type = type;
	}

	public int getType() {
		return type;
	}

	@JsonCreator
	public static UserStatus fromValue(String value) {
		return valueOf(value.toUpperCase());
	}

	@JsonCreator
	public static UserStatus fromType(int typeVal) {
		for (UserStatus us : UserStatus.values()) {
			if (us.getType() == typeVal) {
				return us;
			}
		}

		return null;
	}

	@JsonValue
	public static String toValue(UserStatus type) {
		return type.name().toLowerCase();
	}
}
