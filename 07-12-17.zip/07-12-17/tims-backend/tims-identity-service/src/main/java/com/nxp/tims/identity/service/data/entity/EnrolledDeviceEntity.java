/**
 * Enrolled Device Entity class.
 */
package com.nxp.tims.identity.service.data.entity;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Badari
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "enrolled_devices", schema = "tims")

public class EnrolledDeviceEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/** uuId */
	@Column(name = "uu_id")
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID",strategy = "org.hibernate.id.UUIDGenerator")
	private UUID uuId;

	/** id  */
	@Id
	@Column(name = "id")
	@GeneratedValue(generator = "seq_enrolled_devices")
	@SequenceGenerator(name = "seq_enrolled_devices", sequenceName = "tims.seq_enrolled_devices")
	private Long id;

	
	

	/** deviceId */
	@Column(name = "device_identifier")
	private String deviceId;

	/** deviceOS */
	@Column(name = "device_os")
	private String deviceOS;
	
	/** deviceType */
	@Column(name = "device_type")
	private String deviceType;

	
	@Column(name = "enrolled_application_id")
	private Long enrolledApplicationId;
	
	/** enrolledCertificateId */
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "enrolled_certificates_id")
	private EnrolledCertificateEntity enrolledCertificateEntityByDevice;
	
	
	/** comments */
	@Column(name = "comments")
	private String comments;
	
	
	
}