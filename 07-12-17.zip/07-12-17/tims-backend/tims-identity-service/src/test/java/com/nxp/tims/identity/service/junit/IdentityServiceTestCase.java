package com.nxp.tims.identity.service.junit;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nxp.tims.app.external.request.response.DeviceDetails;
import com.nxp.tims.app.external.request.response.EnrollmentRequest;
import com.nxp.tims.app.external.request.response.EnrollmentResponse;
import com.nxp.tims.app.external.request.response.IdentityRevokeRequest;
import com.nxp.tims.app.external.request.response.UserDetails;
import com.nxp.tims.identity.service.util.IdentityConstants;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class IdentityServiceTestCase {
	
	private final String ENROLL_SERVICE_URL = "http://localhost:8080/"+IdentityConstants.ENROLL_URL;
	
	private final String REVOKEDI_ENDPOINT_URL = "http://localhost:8080/"+IdentityConstants.REVOKE_DI_URL;
	
//	private final String ENROLL_SERVICE_URL = "http://18.216.127.105:8080/tims/enroll";
//	private final String REVOKEDI_ENDPOINT_URL = "http://18.216.127.105:8080/tims/revokeDI";

	
	
	@Test
	public void test_method_1() throws IOException {
		
		byte[] byteArr = Files.readAllBytes(Paths.get("C:/TIMS_USER_CERTIFICATE.txt"));
		String formattedCert = new String(byteArr);
		
		ClientConfig configuration = new ClientConfig();
		configuration.property(ClientProperties.CONNECT_TIMEOUT, 30000);
		configuration.property(ClientProperties.READ_TIMEOUT, 30000);
		Client addClient = ClientBuilder.newClient(configuration);

		EnrollmentRequest enrollmentCertifcateRequest = new EnrollmentRequest();
		enrollmentCertifcateRequest.setCredential(formattedCert);
		enrollmentCertifcateRequest.setAppId("tims");
		DeviceDetails deviceDetails = new DeviceDetails();
		deviceDetails.setId("33");
		deviceDetails.setOs("Android");
		deviceDetails.setType("SmartPhone");
		enrollmentCertifcateRequest.setDeviceDetails(deviceDetails);
		UserDetails userDetails = new UserDetails();
		userDetails.setEmailId("test.test@nxp.com");
		userDetails.setFirstName("Test F");
		userDetails.setLastName("Test L");
		enrollmentCertifcateRequest.setUserDetails(userDetails);
		enrollmentCertifcateRequest.setIssueDerivedIdentity(true);
		WebTarget base = addClient.target(ENROLL_SERVICE_URL);
		Response response = base.request(MediaType.APPLICATION_JSON).post(Entity.json(enrollmentCertifcateRequest));
		int responseStatus = response.getStatus();
		String responseString = response.readEntity(String.class);
		System.out.println("Enroll Service Response for success scenario = "+ responseString);
		assertEquals(responseStatus, 201);
	}
	
	
	
	
	@Test
	public void test_method_2() throws IOException {
		
		byte[] byteArr = Files.readAllBytes(Paths.get("C:/INVALID_TIMS_USER_CERTIFICATE.txt"));
		String formattedCert = new String(byteArr);
		
		ClientConfig configuration = new ClientConfig();
		configuration.property(ClientProperties.CONNECT_TIMEOUT, 10000);
		configuration.property(ClientProperties.READ_TIMEOUT, 10000);
		Client addClient = ClientBuilder.newClient(configuration);

		EnrollmentRequest enrollmentCertifcateRequest = new EnrollmentRequest();
		enrollmentCertifcateRequest.setCredential(formattedCert);
		enrollmentCertifcateRequest.setAppId("tims");
		DeviceDetails deviceDetails = new DeviceDetails();
		deviceDetails.setId("33");
		deviceDetails.setOs("Android");
		deviceDetails.setType("SmartPhone");
		enrollmentCertifcateRequest.setDeviceDetails(deviceDetails);
		UserDetails userDetails = new UserDetails();
		userDetails.setEmailId("test.test@nxp.com");
		userDetails.setFirstName("Test F");
		userDetails.setLastName("Test L");
		enrollmentCertifcateRequest.setUserDetails(userDetails);
		WebTarget base = addClient.target(ENROLL_SERVICE_URL);
		Response response = base.request(MediaType.APPLICATION_JSON).post(Entity.json(enrollmentCertifcateRequest));
		int responseStatus = response.getStatus();
		String responseString = response.readEntity(String.class);
		System.out.println("Enroll Service Response for failure scenario = "+ responseString);
		assertEquals(responseStatus, 400);
		 
	}
 
	@Test
	public void test_method_3(){
		
		try {
			
			byte[] byteArr = Files.readAllBytes(Paths.get("C:/TIMS_USER_CERTIFICATE.txt"));
			String formattedCert = new String(byteArr);
			
			ClientConfig configuration = new ClientConfig();
			configuration.property(ClientProperties.CONNECT_TIMEOUT, 30000);
			configuration.property(ClientProperties.READ_TIMEOUT, 30000);
			Client addClient = ClientBuilder.newClient(configuration);

			EnrollmentRequest enrollmentCertifcateRequest = new EnrollmentRequest();
			enrollmentCertifcateRequest.setCredential(formattedCert);
			enrollmentCertifcateRequest.setAppId("tims");
			DeviceDetails deviceDetails = new DeviceDetails();
			deviceDetails.setId("33");
			deviceDetails.setOs("Android");
			deviceDetails.setType("SmartPhone");
			enrollmentCertifcateRequest.setDeviceDetails(deviceDetails);
			UserDetails userDetails = new UserDetails();
			userDetails.setEmailId("test.test@nxp.com");
			userDetails.setFirstName("Test F");
			userDetails.setLastName("Test L");
			enrollmentCertifcateRequest.setUserDetails(userDetails);
			enrollmentCertifcateRequest.setIssueDerivedIdentity(true);
			WebTarget base = addClient.target(ENROLL_SERVICE_URL);
			Response response = base.request(MediaType.APPLICATION_JSON).post(Entity.json(enrollmentCertifcateRequest));
			int responseStatus = response.getStatus();
			String responseString = response.readEntity(String.class);
			System.out.println("Enroll Service Response for success scenario - testmethod3 = "+ responseString);
			
			
			ObjectMapper objectMapper = new ObjectMapper();
			EnrollmentResponse enrollmentResponse =  objectMapper.readValue(responseString, EnrollmentResponse.class);
			
			
			
			ClientConfig configuration1 = new ClientConfig();
			configuration.property(ClientProperties.CONNECT_TIMEOUT, 10000);
			configuration.property(ClientProperties.READ_TIMEOUT, 10000);
			Client addClient1 = ClientBuilder.newClient(configuration1);
			IdentityRevokeRequest diRevokeRequest = new IdentityRevokeRequest();
			//diRevokeRequest.setDerivedId(enrollmentResponse.getDerviedDI());
			diRevokeRequest.setTokenHash(enrollmentResponse.getTokenHash());
			WebTarget base1 = addClient1.target(REVOKEDI_ENDPOINT_URL);
			Response response1 = base1.request(MediaType.APPLICATION_JSON).put(Entity.json(diRevokeRequest));
			int responseStatus1 = response1.getStatus();
			String responseString1 = response1.readEntity(String.class);
			
			
			
			System.out.println("Revoke Service Response for success scenario = "+ responseString1);
			assertEquals(responseStatus1, 200);
			
		}catch(Exception e){
			
		}
		
	}
	
	
	
	 
	@Test
	public void test_method_4(){
		ClientConfig configuration = new ClientConfig();
		configuration.property(ClientProperties.CONNECT_TIMEOUT, 10000);
		configuration.property(ClientProperties.READ_TIMEOUT, 10000);
		Client addClient = ClientBuilder.newClient(configuration);
		IdentityRevokeRequest diRevokeRequest = new IdentityRevokeRequest();
		WebTarget base = addClient.target(REVOKEDI_ENDPOINT_URL);
		Response response = base.request(MediaType.APPLICATION_JSON).put(Entity.json(diRevokeRequest));
		int responseStatus = response.getStatus();
		String responseString = response.readEntity(String.class);
		System.out.println("Revoke Service Response for failure scenario = "+ responseString);
		assertEquals(responseStatus, 400);
	}
 
}
