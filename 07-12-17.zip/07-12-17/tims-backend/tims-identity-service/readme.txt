

delete from tims.enrolled_devices;
delete from tims.derived_identites;
delete from tims.enrolled_certificates;

commit;