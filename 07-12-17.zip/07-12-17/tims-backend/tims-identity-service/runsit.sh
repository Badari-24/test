
cd build
cd libs

java -jar  -Dspring.profiles.active=sit tims-identity-service-0.0.1-SNAPSHOT.jar 