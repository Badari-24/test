package com.nxp.tims.validation.util;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.cert.CertificateEncodingException;

import org.apache.commons.io.IOUtils;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.ocsp.OCSPObjectIdentifiers;
import org.bouncycastle.asn1.x509.ExtensionsGenerator;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.ocsp.CertificateID;
import org.bouncycastle.cert.ocsp.OCSPException;
import org.bouncycastle.cert.ocsp.OCSPReq;
import org.bouncycastle.cert.ocsp.OCSPReqBuilder;
import org.bouncycastle.cert.ocsp.OCSPResp;
import org.bouncycastle.operator.DigestCalculatorProvider;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.bc.BcDigestCalculatorProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OCSPUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OCSPUtil.class);

	public OCSPUtil() {}

	/**
	 * Builds the OCSP request 
	 *
	 * @param  Certificate Object which needs to be validated 
	 * @return  OCSP Request Object
	 */
	public static OCSPReq buildOCSPRequest(BigInteger certificateSerialNumber, AppProperties timsProperties)
					throws CertificateEncodingException, IOException, OperatorCreationException, OCSPException {
		LOGGER.info("End user certificate serial number : "+ certificateSerialNumber);
		X509CertificateHolder certificateCA =  null;
		String issuerCertificate = getIssuerCertificate(timsProperties.getIssuerCertificateFilePath());
		certificateCA = ValidationUtil.convertToX509Certificate(issuerCertificate);
		LOGGER.info("Issuer certificate serial number : "+ certificateCA.getSerialNumber());
		OCSPReqBuilder builder = new OCSPReqBuilder();
		DigestCalculatorProvider provider = new BcDigestCalculatorProvider();
		CertificateID certificateID = new CertificateID(provider.get(CertificateID.HASH_SHA1), certificateCA,
				certificateSerialNumber);
		
		BigInteger nonce = BigInteger.valueOf(System.currentTimeMillis());
		builder.addRequest(certificateID);
		ExtensionsGenerator extensionsGenerator = new ExtensionsGenerator();
		extensionsGenerator.addExtension(OCSPObjectIdentifiers.id_pkix_ocsp_nonce, false,
				new DEROctetString(nonce.toByteArray()));

		return builder.build();
	}

	/**
	 * Sends the OCSP server request 
	 *
	 * @param  OCSP request object
	 * @param  OCSP server URL
	 * @return  OCSP response object
	 */
	public static OCSPResp sendOCSPRequest(OCSPReq request, AppProperties timsProperties) throws IOException {
		OCSPResp ocspResp = null;

		byte[] breq = request.getEncoded();
		URL url = new URL(timsProperties.getOcspServerURL());
		URLConnection con = url.openConnection();
		con.setReadTimeout(timsProperties.getOcspReadTimeOut());
		con.setConnectTimeout(timsProperties.getOcspConnectionTimeOut());
		con.setUseCaches(false);
		con.setDoOutput(true);
		con.setDoInput(true);

		// Send the OCSP request
		con.setRequestProperty(ValidationConstants.CONTENT_TYPE_PROPERTY, ValidationConstants.CONTENT_TYPE_VALUE);
		con.setRequestProperty(ValidationConstants.CONTENT_TRANSFER_ENCODING_PROPERTY, ValidationConstants.CONTENT_TRANSFER_ENCODING_BINARY);
		OutputStream os = con.getOutputStream();
		os.write(breq);
		os.close();

		// Read the response
		byte[] bresp = IOUtils.toByteArray(con.getInputStream());
		ocspResp = new OCSPResp(bresp);
		LOGGER.info("Sending OCSP response is successful"+ocspResp.toString());
		return ocspResp;
	}

	

	private static String getIssuerCertificate(String filePath){
		LOGGER.info("Read file method");
		byte[] byteArr = null;
		try {
			byteArr = Files.readAllBytes(Paths.get(filePath));
		} catch (IOException e) {			
			LOGGER.error("Error in getIssuerCertificate : "+ e.getMessage());
		}
		return new String(byteArr);
	}
	
}
