/**
 * Invalid Search Exception class
 */
package com.nxp.tims.validation.exception;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Suresh
 *
 */
@NoArgsConstructor
@ToString(callSuper = true)
@Getter
@Setter
public class InvalidSearchException extends RuntimeException {
    /**
     *  InvalidSearchException implementation.
     *  
     * @param s
     */
	public InvalidSearchException(String s) {
        super(s);
    }
}
