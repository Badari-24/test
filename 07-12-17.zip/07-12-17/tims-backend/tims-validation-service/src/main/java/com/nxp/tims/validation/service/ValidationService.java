/**
 * Service class for this application.
 */
package com.nxp.tims.validation.service;

import java.io.IOException;
import java.math.BigInteger;
import java.security.cert.CertificateEncodingException;

import org.bouncycastle.asn1.ocsp.OCSPResponseStatus;
import org.bouncycastle.cert.ocsp.BasicOCSPResp;
import org.bouncycastle.cert.ocsp.OCSPException;
import org.bouncycastle.cert.ocsp.OCSPReq;
import org.bouncycastle.cert.ocsp.OCSPResp;
import org.bouncycastle.cert.ocsp.SingleResp;
import org.bouncycastle.operator.OperatorCreationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nxp.tims.validation.util.AppProperties;
import com.nxp.tims.validation.util.OCSPUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Badari
 *
 */
@Slf4j
@Service
public class ValidationService {
	
	/** Logger for this class */
	private static final Logger LOGGER = LoggerFactory.getLogger(ValidationService.class);

	@Autowired
	private AppProperties timsProperties;

	/**
	 * Validate certificate with issuer.
	 * 
	 * @param X509 Certificate Object
	 * @return validation status in boolean
	 */
	public SingleResp validateWithOCSPIssuer(BigInteger certificateSerialNumber) {

		OCSPReq request = null;
		OCSPResp response = null;
		Object responseObject = null;
		SingleResp singleResponse = null;

		try {
			request = OCSPUtil.buildOCSPRequest(certificateSerialNumber, timsProperties);
			response = OCSPUtil.sendOCSPRequest(request, timsProperties);
			responseObject = response.getResponseObject();

			if (response.getStatus() == OCSPResponseStatus.SUCCESSFUL) {

				if (responseObject instanceof BasicOCSPResp) {

					BasicOCSPResp basicOCSPResp = (BasicOCSPResp) responseObject;
					SingleResp[] singleResponses = basicOCSPResp.getResponses();
					if(singleResponses.length != 0){
						singleResponse = singleResponses[0];
					}			
				}
			}

		} catch (CertificateEncodingException e) {
			LOGGER.error("Certificate encoding exception: " + e.getMessage());
		} catch (OperatorCreationException e) {
			LOGGER.error("Operator creation exception: " + e.getMessage());
		} catch (IOException e) {
			LOGGER.error("IO exception: " + e.getMessage());
		} catch (OCSPException e) {
			LOGGER.error("OCSP exception: " + e.getMessage());
		}
		return singleResponse;
	}

}
