/**
* The TIMSConfig program is  extending ResourceConfig. Registeres the classes.  
* 
*
* @author  Suresh 
* @version 1.0
* @since   2017-10-30 
*/
package com.nxp.tims.validation.config;

import java.util.UUID;

import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.dozer.loader.api.TypeMappingOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.nxp.tims.validation.interceptor.ValidationServiceInterceptor;
import com.nxp.tims.validation.util.UuidBeanFactory;

/**
 * 
 * @author Suresh
 *
 */
@Component
public class ValidationConfiguration extends WebMvcConfigurerAdapter {

    /**
     * Dozer implementation.
     * 
     * @return
     */
	@Bean
    public static Mapper getMapper() {
        BeanMappingBuilder builder = new BeanMappingBuilder() {
            protected void configure() {
                mapping(UUID.class, UUID.class, TypeMappingOptions.oneWay(),
                        TypeMappingOptions.beanFactory(
                                UuidBeanFactory.class.getName()));
            }
        };

        DozerBeanMapper mapper = new DozerBeanMapper();
        mapper.addMapping(builder);

        return mapper;
    }
  
    
    /**
     * Injecting CredValidationServiceInterceptor
     */
	@Autowired
	private ValidationServiceInterceptor credValidationServiceInterceptor;

    /**
     * addInterceptors to this application.
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(credValidationServiceInterceptor)
          .addPathPatterns("/**/timsValidation/**/");
    }
    
}
