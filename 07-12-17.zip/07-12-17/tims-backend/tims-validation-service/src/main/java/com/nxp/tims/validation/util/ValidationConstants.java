/**
 * Constants file for this application.
 */
package com.nxp.tims.validation.util;

/**
 * 
 * @author Badari
 *
 */
public class ValidationConstants {

	/** VALIDATE_URL */
	public static final String VALIDATE_URL = "/timsValidation/validateWithIssuer";

	/** STATUS_VALID */
	public static final String STATUS_VALID = "VALID";

	/** SERVICE_ERR_MSG */
	public static final String SERVICE_ERR_MSG = "Service Unavailable";

	public static final boolean isUniqueValueGenerationRequiredforTesting = false;

	public static final String CONTENT_TYPE_PROPERTY = "Content-Type";

	public static final String CONTENT_TYPE_VALUE = "application/ocsp-request";

	public static final String CONTENT_TRANSFER_ENCODING_PROPERTY = "Content-Transfer-Encoding";

	public static final String CONTENT_TRANSFER_ENCODING_BINARY = "binary";

}
