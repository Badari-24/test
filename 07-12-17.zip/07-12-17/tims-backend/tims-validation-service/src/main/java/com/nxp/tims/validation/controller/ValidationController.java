/**
 * This class exposes application services as REST services. 
 */
package com.nxp.tims.validation.controller;

import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.ocsp.SingleResp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nxp.tims.app.external.request.response.BaseResponse;
import com.nxp.tims.app.request.response.ValidateCertificateRequest;
import com.nxp.tims.validation.service.ValidationService;
import com.nxp.tims.validation.util.AppProperties;
import com.nxp.tims.validation.util.ValidationConstants;
import com.nxp.tims.validation.util.ValidationUtil;

import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author Badari
 *
 */
@RestController
public class ValidationController {

	/** Logger for this class */
	private static final Logger LOGGER = LoggerFactory.getLogger(ValidationController.class);

	/** Injecting CredValidationService into this class */
	@Autowired
	private ValidationService credentialValidationService;
	
	@Autowired
	private AppProperties timsProperties;

	/**
	 * Validates X509 certificate with issuer using OCSP protocol.
	 * 
	 * @param certificateRequestVO
	 * @return
	 */
	@ApiOperation(value = "Validate X509 Certificate with issuer", notes = "Requires X509 certificate", response = ValidateCertificateRequest.class)
	@RequestMapping(method = RequestMethod.POST, value = ValidationConstants.VALIDATE_URL, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public BaseResponse validateWithIssuer(@RequestBody ValidateCertificateRequest validateCertificateRequest) {
		LOGGER.info("ValidateCertController entered into checkCertValidation() method");
		String errorMessage = "";

		try {
			// Request Valid flow - start
			X509CertificateHolder x509Certificate = ValidationUtil
					.convertToX509Certificate(validateCertificateRequest.getCredential());
			if (x509Certificate != null) {
					SingleResp ocspResponse = credentialValidationService.validateWithOCSPIssuer(x509Certificate.getSerialNumber());
					if (null != x509Certificate.getSerialNumber() && null != ocspResponse) {
						return ValidationUtil.populateCertificateResponse(x509Certificate , ocspResponse, timsProperties.getOcspServerURL());
					} else {
						// OCSP Validation is failed
						return ValidationUtil.returnErrorResponse(2002, "OCSP Validation is failed !!", null);
					}
			} else {
				return ValidationUtil.returnErrorResponse(2001, "Basic Certificate validation failed !!", null);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			errorMessage = e.getMessage();

		}

		LOGGER.info("Exist from : ValidateCertController checkCertValidation() method");
		return ValidationUtil.returnErrorResponse(2003, errorMessage, null);
	}
	
	 @RequestMapping("/")
	  public String rootindex() {
	        return "Root::Validation Service is Running!!";
	  }
	

}