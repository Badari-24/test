/**
 * Interceptor class for this application.
 */
package com.nxp.tims.validation.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * 
 * @author Suresh
 *
 */
@Component
public class ValidationServiceInterceptor extends HandlerInterceptorAdapter {
	

	private static final Logger LOGGER = LoggerFactory.getLogger(ValidationServiceInterceptor.class);
	
	/**
	 *  preHandle implementation.
	 *  	
	 */
	@Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response,  Object handler) {
	 long startTime = System.currentTimeMillis();
//	 LOGGER.info("Request URL::" + request.getRequestURL().toString()
	//			+ ":: Start Time=" + System.currentTimeMillis());
	 request.setAttribute("startTime", startTime);
        return true;
    }
	 
	/**
	 * postHandle implementation.
	 */
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		//System.out.println("UserManagementServiceInterceptor - PostHandler - Request URL::" + request.getRequestURL().toString()
			//	+ " Sent to Handler :: Current Time=" + System.currentTimeMillis());
		//we can add attributes in the modelAndView and use that in the view page
	}
	 
	 
    /**
     * afterCompletion implementation.
     */
	@Override
    public void afterCompletion(
      HttpServletRequest request, 
      HttpServletResponse response, 
      Object handler, 
      Exception ex) {
    	
    	long startTime = (Long) request.getAttribute("startTime");
    	long timeTaken = System.currentTimeMillis() - startTime;
    	String message = ",Request URL:"+request.getRequestURL().toString()+", Elpased Time(ms): "+timeTaken;
    	LOGGER.info(message);
    			/*
    	LOGGER.info("Request URL::" + request.getRequestURL().toString()
				+ ":: End Time=" + System.currentTimeMillis());
    	LOGGER.info("Request URL::" + request.getRequestURL().toString()
				+ ":: Time Taken=" + (System.currentTimeMillis() - startTime));
		*/
    	//System.out.println("UserManagementServiceInterceptor - afterCompletion ");
    }

}
