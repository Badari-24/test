package com.nxp.tims.app.request.response;

public enum ValidationServiceResponseStatusEnum {

	VALID_CERTIFICATE(1),INVALID_CERTIFICATE(2),OCSP_VALIDATION_SUCCESS(3),REVOKED(4),FAILED(-1);
	
	private int id;
	
	ValidationServiceResponseStatusEnum(int id){
		this.id = id; 
	}
	
	public int id(){
		return id; 
	}
}
