package com.nxp.tims.validation.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.x509.Certificate;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.ocsp.CertificateID;
import org.bouncycastle.cert.ocsp.CertificateStatus;
import org.bouncycastle.cert.ocsp.RevokedStatus;
import org.bouncycastle.cert.ocsp.SingleResp;
import org.bouncycastle.operator.DefaultAlgorithmNameFinder;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.encoders.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nxp.tims.app.external.request.response.BaseResponse;
import com.nxp.tims.app.request.response.ValidateCertificateResponse;
import com.nxp.tims.app.request.response.ValidationServiceResponseStatusEnum;
import com.nxp.tims.validation.exception.ErrorInfo;

public class ValidationUtil {


	private static final Logger LOGGER = LoggerFactory.getLogger(ValidationUtil.class);
	
	
	/**
	 * Common method to return error response.
	 * 
	 * @param errorCode
	 * @param businessMessage
	 * @param type
	 * @return
	 */
	public static BaseResponse returnErrorResponse(int errorCode, String businessMessage, String type) {
		BaseResponse baseResponse = new BaseResponse();
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setCode(errorCode);
		errorInfo.setMessage(businessMessage);
		errorInfo.setType(type);
		baseResponse.setErrorInfo(errorInfo);
		return baseResponse;
	}
	
	/**
	 * Generates a X509 Certificate object
	 *
	 * @param  X509 Certificate in the form byte Stream
	 * @return  X509 Certificate object
	 */
	public static X509CertificateHolder convertToX509Certificate(String certificate) {
		
		LOGGER.info("The certificate is coming as"+ certificate);
		
		X509CertificateHolder x509CertificateHolder = null;
		ByteArrayInputStream bIn = new ByteArrayInputStream(Base64
						.decode(certificate));
		@SuppressWarnings("resource")
		ASN1InputStream aIn = new ASN1InputStream(bIn);
		ASN1Sequence seq = null;
		try {
			seq = (ASN1Sequence) aIn.readObject();
			x509CertificateHolder = new X509CertificateHolder(Certificate.getInstance(seq));
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}
		return x509CertificateHolder;
	}
	


	
	/**
	 * It creates the final response object based 
	 * on the OCSP response and end user certificate 
	 * @param Certificate
	 * @param OCSP response 
	 * @param OCSP URL
	 * @return Certificate response
	 */
	public static ValidateCertificateResponse populateCertificateResponse(X509CertificateHolder x509Certificate, SingleResp ocspResponse, String ocspUrl) {

			ValidateCertificateResponse validateCertificateResponse = new ValidateCertificateResponse();
			CertificateStatus certificateStatus = ocspResponse.getCertStatus();
				
				if (ValidationConstants.isUniqueValueGenerationRequiredforTesting) {
					java.util.Date date = new java.util.Date();
					validateCertificateResponse
							.setSerialNo(x509Certificate.getSerialNumber().toString() + ":TEST:" + date.getTime());
					validateCertificateResponse
							.setIssuerDN(x509Certificate.getIssuer().toString() + ":TEST:" + date.getTime());
				} else {
					validateCertificateResponse.setSerialNo(x509Certificate.getSerialNumber().toString());
					validateCertificateResponse.setIssuerDN(x509Certificate.getIssuer().toString());
				}
				if (certificateStatus == CertificateStatus.GOOD) {
					validateCertificateResponse
					.setValidationServiceResponseStatus(ValidationServiceResponseStatusEnum.OCSP_VALIDATION_SUCCESS);
				} else if (certificateStatus instanceof RevokedStatus) {
					validateCertificateResponse
					.setValidationServiceResponseStatus(ValidationServiceResponseStatusEnum.REVOKED);
/*					revokedStatus = (RevokedStatus) certificateStatus;
					int reason = 0;
					if (revokedStatus.hasRevocationReason()) {
						reason = revokedStatus.getRevocationReason();
					}
					Date time = revokedStatus.getRevocationTime();
					LOGGER.info("OCSP certificate has been revoked on " + time + " for the reason identifier = "
							+ reason, true);*/
				} else {
					validateCertificateResponse
					.setValidationServiceResponseStatus(ValidationServiceResponseStatusEnum.INVALID_CERTIFICATE);
				}

				validateCertificateResponse.setFingerPrint(FingerPrintUtil.getThumbPrint(x509Certificate));
	
				validateCertificateResponse.setIssuerKeyHash(new String(Hex.encode(ocspResponse.getCertID().getIssuerKeyHash())));
	
				validateCertificateResponse.setIssuerNameHash(new String(Hex.encode(ocspResponse.getCertID().getIssuerNameHash())));
				validateCertificateResponse
						.setHashAlogorithm(new DefaultAlgorithmNameFinder().getAlgorithmName(CertificateID.HASH_SHA1));
				validateCertificateResponse.setOcspUrl(ocspUrl);
	
				if (x509Certificate.getIssuer() != null && x509Certificate.getIssuer().toString() != null) {
					String[] split = x509Certificate.getIssuer().toString().split(",");
					for (String x : split) {
						if (x.contains("CN=")) {
							System.out.println(x.trim());
						}
					}
				}
	
				// {"valid":false,"serialNo":"12643669867487359828","issuerDN":"C=IN,ST=Karnataka,L=Bengaluru,O=Test,OU=MIG,CN=test@test.com","status":"VALID","hashAlogorithm":null,"issuerKeyHash":null,"issuerNameHash":null,"errorInfo":null}
	
		
		return validateCertificateResponse;
	}		
	
}
