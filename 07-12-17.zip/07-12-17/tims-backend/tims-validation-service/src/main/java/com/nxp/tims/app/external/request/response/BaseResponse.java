package com.nxp.tims.app.external.request.response;



import com.nxp.tims.validation.exception.ErrorInfo;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BaseResponse {

	private ErrorInfo errorInfo;
//	private String statusCode;
}
