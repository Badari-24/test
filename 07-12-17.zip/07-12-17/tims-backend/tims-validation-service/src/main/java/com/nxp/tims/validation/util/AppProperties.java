/**
 * 
 */
package com.nxp.tims.validation.util;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Lipika
 *
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Component
@ConfigurationProperties(prefix = "tims") // prefix app, find user.* values
public class AppProperties {

	/** OCSP Server URL */
	private String ocspServerURL;
	private int ocspReadTimeOut;
	private int ocspConnectionTimeOut;
	private String issuerCertificateFilePath;

	 
}