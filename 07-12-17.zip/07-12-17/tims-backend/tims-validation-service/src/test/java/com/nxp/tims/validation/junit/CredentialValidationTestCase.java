package com.nxp.tims.validation.junit;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nxp.tims.app.request.response.ValidateCertificateRequest;
import com.nxp.tims.app.request.response.ValidateCertificateResponse;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CredentialValidationTestCase {
	
	private final String VALIDATION_SERVICE_URL = "http://localhost:8085/timsValidation/validateWithIssuer";
	
	@Test
	public void test_method_1() throws IOException {
		byte[] byteArr = Files.readAllBytes(Paths.get("C:/TIMS_USER_CERTIFICATE.txt"));
		String formattedCert = new String(byteArr);

		ClientConfig configuration = new ClientConfig();
		configuration.property(ClientProperties.CONNECT_TIMEOUT, 5000);
		configuration.property(ClientProperties.READ_TIMEOUT, 5000);

		Client addClient = ClientBuilder.newClient(configuration);

		ValidateCertificateRequest validateCertificateRequest = new ValidateCertificateRequest();
		validateCertificateRequest.setCredential(formattedCert);

		WebTarget base = addClient.target(VALIDATION_SERVICE_URL);
		Response response = base.request(MediaType.APPLICATION_JSON).post(Entity.json(validateCertificateRequest));
		int responseStatus = response.getStatus();
		String responseString = response.readEntity(String.class);
		System.out.println("Response from validate with issuer service - success = " + responseString);
		assertEquals(responseStatus, 200);
	}
	
	@Test
	public void test_method_2() throws Exception {
		byte[] byteArr = Files.readAllBytes(Paths.get("C:/INVALID_TIMS_USER_CERTIFICATE.txt"));
		String formattedCert = new String(byteArr);

		ClientConfig configuration = new ClientConfig();
		configuration.property(ClientProperties.CONNECT_TIMEOUT, 5000);
		configuration.property(ClientProperties.READ_TIMEOUT, 5000);
		Client addClient = ClientBuilder.newClient(configuration);

		ValidateCertificateRequest validateCertificateRequest = new ValidateCertificateRequest();
		validateCertificateRequest.setCredential(formattedCert);

		WebTarget base = addClient.target(VALIDATION_SERVICE_URL);
		Response response = base.request(MediaType.APPLICATION_JSON).post(Entity.json(validateCertificateRequest));
		int responseStatus = response.getStatus();
		String responseString = response.readEntity(String.class);
		System.out.println("Response from validate with issuer service - failure = " + responseString);
		System.out.println(responseStatus);
		
		ObjectMapper objectMapper = new ObjectMapper();
		ValidateCertificateResponse errorInfo =  objectMapper.readValue(responseString, ValidateCertificateResponse.class);
		
		assertEquals(errorInfo.getErrorInfo().getCode(), 2001);
	}

}