
cd build
cd libs

java -jar  -Dspring.profiles.active=dev tims-cred-validation-0.1.0.jar & 